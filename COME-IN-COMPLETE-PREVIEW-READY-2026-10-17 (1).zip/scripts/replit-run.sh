#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FRONTEND_DIR="$ROOT/frontend"
BACKEND_DIR="$ROOT/backend"
BACKEND_PORT="${PORT_BACKEND:-8000}"
FRONTEND_PORT="${PORT:-3000}"
BACKEND_PID=""
FRONTEND_PID=""

log() { printf '[COME-IN Replit] %s\n' "$*"; }
cleanup() {
  trap - INT TERM EXIT
  [[ -z "$FRONTEND_PID" ]] || kill "$FRONTEND_PID" 2>/dev/null || true
  [[ -z "$BACKEND_PID" ]] || kill "$BACKEND_PID" 2>/dev/null || true
  wait 2>/dev/null || true
}
trap cleanup INT TERM EXIT

if [[ ! -d "$FRONTEND_DIR/node_modules" ]]; then
  log "Frontend dependencies missing; using the project's declared Yarn package manager."
  if command -v yarn >/dev/null 2>&1; then
    (cd "$FRONTEND_DIR" && yarn install --non-interactive) || { log "Frontend dependency installation failed; see Yarn output above and check registry/network access."; exit 1; }
  elif command -v corepack >/dev/null 2>&1; then
    (cd "$FRONTEND_DIR" && corepack yarn install --non-interactive) || { log "Frontend dependency installation failed; see Corepack/Yarn output above and check registry/network access."; exit 1; }
  else
    log "Cannot install frontend dependencies: Yarn/Corepack is unavailable. Run bash ./scripts/replit-install.sh in a Node environment with Corepack/Yarn and registry access."
    exit 1
  fi
fi

# The frontend should still be previewable when the owner has not configured a
# database yet. Never invent a database URL or secret; clearly report why API
# functionality is unavailable and keep the UI process alive.
if [[ -z "${MONGO_URL:-}" || -z "${DB_NAME:-}" || -z "${JWT_SECRET:-}" || "${JWT_SECRET:-}" == "replace-with-a-long-random-secret" ]]; then
  log "Backend NOT started: configure MONGO_URL, DB_NAME and a unique JWT_SECRET in Replit Secrets. Frontend preview will still start; API-backed features need the backend."
else
  if ! python -c 'import fastapi, uvicorn, motor, pymongo' >/dev/null 2>&1; then
    log "Backend dependencies missing; installing backend/requirements.txt."
    python -m pip install -r "$BACKEND_DIR/requirements.txt"
  fi
  export CORS_ORIGINS="${CORS_ORIGINS:-*}"
  export PORT_BACKEND="$BACKEND_PORT"
  log "Starting FastAPI on 0.0.0.0:${BACKEND_PORT} (logs follow)."
  (cd "$BACKEND_DIR" && python -m uvicorn server:app --host 0.0.0.0 --port "$BACKEND_PORT") &
  BACKEND_PID=$!
fi

log "Starting Expo Web on 0.0.0.0:${FRONTEND_PORT}."
if [[ -z "${EXPO_PUBLIC_BACKEND_URL:-}" ]]; then
  log "WARNING: EXPO_PUBLIC_BACKEND_URL is not set. The app may render, but browser API requests will not reach a remote backend. Set it to the externally reachable backend URL and restart Expo."
fi
(cd "$FRONTEND_DIR" && npx expo start --web --host lan --port "$FRONTEND_PORT") &
FRONTEND_PID=$!

while true; do
  if ! kill -0 "$FRONTEND_PID" 2>/dev/null; then
    wait "$FRONTEND_PID" || rc=$?
    log "Frontend process exited (status ${rc:-0})."
    exit "${rc:-1}"
  fi
  if [[ -n "$BACKEND_PID" ]] && ! kill -0 "$BACKEND_PID" 2>/dev/null; then
    wait "$BACKEND_PID" || rc=$?
    log "Backend process exited (status ${rc:-0}); stopping combined run."
    exit "${rc:-1}"
  fi
  sleep 2
done
