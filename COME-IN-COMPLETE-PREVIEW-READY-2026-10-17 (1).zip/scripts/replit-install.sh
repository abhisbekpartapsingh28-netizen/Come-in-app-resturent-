#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

fail() { printf '[COME-IN install] ERROR: %s\n' "$*" >&2; exit 1; }
command -v node >/dev/null 2>&1 || fail 'Node.js is required for the Expo frontend.'
command -v corepack >/dev/null 2>&1 || command -v yarn >/dev/null 2>&1 || fail 'Yarn 1.22.22 is declared by frontend/package.json, but neither Corepack nor Yarn is installed.'
command -v python >/dev/null 2>&1 || fail 'Python is required for the FastAPI backend.'

printf '[COME-IN install] Installing frontend using the declared Yarn package manager.\n'
if command -v yarn >/dev/null 2>&1; then
  (cd "$ROOT/frontend" && yarn install --non-interactive) || fail 'Frontend dependency installation failed. Read the Yarn error above; check registry/network access. No registry retry was attempted.'
else
  (cd "$ROOT/frontend" && corepack yarn install --non-interactive) || fail 'Frontend dependency installation failed. Read the Corepack/Yarn error above; check registry/network access. No registry retry was attempted.'
fi

printf '[COME-IN install] Installing backend packages from backend/requirements.txt.\n'
python -m pip install -r "$ROOT/backend/requirements.txt" || fail 'Backend dependency installation failed. Check Python version, package index access, and the pip error above.'
printf '[COME-IN install] Installation completed.\n'
