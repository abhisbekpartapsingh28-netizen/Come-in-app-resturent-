import { useCallback, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { storage } from '@/src/utils/storage';
import { RestaurantPage, rs } from '@/src/restaurant/RestaurantPage';
import { restaurantTheme as t } from '@/src/restaurant/theme';
import { getMyRestaurantOrders } from '@/src/restaurant/api';
import { useAuth } from '@/src/store/auth';
type Order={id:string;createdAt:string;status:string;total:number;items:{name:string;quantity:number;price:number}[];address:string};
export default function RestaurantAccount(){
  const router=useRouter();
  const {user,logout}=useAuth();
  const [orders,setOrders]=useState<Order[]>([]);
  const [liveOrders,setLiveOrders]=useState<any[]>([]);
  const [liveNotice,setLiveNotice]=useState('');
  useFocusEffect(useCallback(()=>{
    let active=true;
    storage.getItem<string>('@comein_restaurant_demo_orders_v1','[]').then(v=>{
      if(!active)return;
      try{const parsed=JSON.parse(v??'[]');setOrders(Array.isArray(parsed)?parsed:[])}catch{setOrders([])}
    });
    getMyRestaurantOrders().then(rows=>{if(active){setLiveOrders(rows);setLiveNotice('')}}).catch(()=>{if(active)setLiveNotice('Sign in and connect the backend to view server-saved food orders.')});
    return()=>{active=false};
  },[]));
  return <RestaurantPage title="Your food account" subtitle="Server orders and local demo history are kept separate">
    <View style={rs.card}>
      <Text style={rs.heading}>Restaurant Mode</Text>
      <Text style={rs.muted}>{user?`Signed in as ${user.name} · ${user.email}`:'You are browsing as a guest.'}</Text>
      {user?<Pressable style={rs.chip} onPress={async()=>{await logout();setLiveOrders([]);setLiveNotice('Signed out. Server-saved orders require sign-in.')}}><Text style={rs.chipText}>Sign out</Text></Pressable>:<Pressable style={rs.chip} onPress={()=>router.push({pathname:'/auth',params:{next:'/restaurant/account'}} as never)}><Text style={rs.chipText}>Sign in / create account</Text></Pressable>}
      <Text style={rs.muted}>The Restaurant Mode cart is separate from your Shopping Mode cart.</Text>
      <Pressable style={rs.button} onPress={()=>router.replace('/(tabs)' as never)}><Text style={rs.buttonText}>Switch to Shopping Mode</Text></Pressable>
      <Pressable style={rs.chip} onPress={()=>router.push('/orders' as never)}><Text style={rs.chipText}>Open shopping orders</Text></Pressable>
    </View>
    <Pressable style={rs.chip} onPress={()=>router.push('/restaurant/addresses' as never)}><Text style={rs.chipText}>Manage saved addresses</Text></Pressable>
    <Pressable style={rs.button} onPress={()=>router.push('/restaurant/dashboard' as never)}><Text style={rs.buttonText}>Restaurant owner dashboard</Text></Pressable>
    <Text style={rs.heading}>Your server-saved food orders</Text>
    {liveNotice?<Text style={rs.muted}>{liveNotice}</Text>:null}
    {liveOrders.map(o=><Pressable key={o.id} style={rs.card} onPress={()=>router.push({pathname:'/restaurant/orders/[id]',params:{id:o.id}} as never)}><Text style={{color:t.text,fontWeight:'900'}}>{o.ref} · ₹{o.total}</Text><Text style={rs.muted}>{o.restaurant_name} · {o.status} · payment: {o.payment_status}</Text><Text style={rs.muted}>{(o.items||[]).map((i:any)=>`${i.name} × ${i.quantity}`).join(', ')}</Text><Text style={rs.chipText}>View status history →</Text></Pressable>)}
    <Text style={rs.heading}>Local demo orders</Text>
    {orders.length===0?<View style={rs.card}><Text style={rs.muted}>No locally saved demo orders yet.</Text></View>:orders.map(o=><View key={o.id} style={rs.card}><Text style={{color:t.text,fontWeight:'900'}}>{o.id} · ₹{o.total}</Text><Text style={rs.muted}>{new Date(o.createdAt).toLocaleString()}</Text><Text style={rs.muted}>{o.items.map(i=>`${i.name} × ${i.quantity}`).join(', ')}</Text><Text style={{color:t.accent,fontSize:11,fontWeight:'800'}}>{o.status}</Text></View>)}
  </RestaurantPage>;
}
