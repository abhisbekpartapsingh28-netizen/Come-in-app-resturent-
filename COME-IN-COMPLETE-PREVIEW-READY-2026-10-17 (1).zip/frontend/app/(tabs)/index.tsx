import Feather from "@react-native-vector-icons/feather";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BrandLogo } from "@/src/components/BrandLogo";
import { ProductCard } from "@/src/components/ProductCard";
import {
  CATEGORIES,
  POPULAR_PRODUCTS,
  QUICK_DELIVERY_PRODUCTS,
  SERVICES,
} from "@/src/data/catalog";
import { useT } from "@/src/i18n";
import { useLocationCtx } from "@/src/store/location";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

const DEFAULT_LOCATION = "Set delivery location";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { location, setLocation } = useLocationCtx();
  const { t } = useT();
  const [locModalOpen, setLocModalOpen] = useState(false);
  const [locInput, setLocInput] = useState(
    location === DEFAULT_LOCATION ? "" : location,
  );

  // Re-sync the modal input with the currently-saved location every time
  // the modal is opened so stale text from a prior session isn't shown
  // after the address was changed from Account / Request Anything.
  useEffect(() => {
    if (locModalOpen) {
      setLocInput(location === DEFAULT_LOCATION ? "" : location);
    }
  }, [locModalOpen, location]);

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" />
      {/* Sticky Header */}
      <View
        style={[styles.header, { paddingTop: insets.top + spacing.sm }]}
      >
        <View style={styles.topRow}>
          <View style={styles.brandLogoWrap}>
            <BrandLogo testID="brand-logo" size="md" />
          </View>
          <View style={styles.headerActions}>
            <Pressable testID="header-voice-search" accessibilityRole="button" accessibilityLabel="Voice search unavailable; use text search" onPress={() => Alert.alert("Voice search unavailable", "Speech recognition is not configured for this app. You can still search by typing.")} style={styles.headerAction}>
              <Feather name="mic" size={19} color={colors.brandForest} />
            </Pressable>
            <Pressable testID="header-language" accessibilityRole="button" accessibilityLabel="Choose language" onPress={() => router.push("/language")} style={styles.headerAction}>
              <Feather name="globe" size={19} color={colors.brandForest} />
            </Pressable>
            <Pressable testID="header-notifications" accessibilityRole="button" accessibilityLabel="View orders and updates" onPress={() => router.push("/orders")} style={styles.headerAction}>
              <Feather name="bell" size={19} color={colors.brandForest} />
            </Pressable>
            <Pressable testID="header-account" accessibilityRole="button" accessibilityLabel="Open account" onPress={() => router.push("/(tabs)/account")} style={[styles.headerAction, styles.headerAccountAction]}>
              <Feather name="user" size={19} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>
      </View>
      {/* Search sits on the mint page surface, directly below the yellow brand header. */}
      <View style={styles.searchArea}>
        <View style={styles.searchRow}>
          <Pressable
            testID="home-search-bar"
            accessibilityRole="button"
            onPress={() => router.push("/(tabs)/search")}
            style={styles.searchBar}
          >
            <Feather name="search" size={18} color={colors.brandForest} />
            <Text style={styles.searchPlaceholder}>{t("home.searchPlaceholder")}</Text>
          </Pressable>
          <Pressable
            testID="home-filter-button"
            accessibilityRole="button"
            accessibilityLabel="Browse categories and filters"
            onPress={() => router.push("/(tabs)/categories")}
            style={styles.filterButton}
          >
            <Feather name="sliders" size={19} color={colors.brandForest} />
          </Pressable>
        </View>
        {/* Keep the existing delivery-location selector functional without expanding the yellow header. */}
        <Pressable
          testID="location-selector"
          accessibilityRole="button"
          onPress={() => setLocModalOpen(true)}
          style={styles.locRow}
        >
          <Feather name="map-pin" size={14} color={colors.brandPrimary} />
          <Text style={styles.locLabel}>{t("home.deliverTo")}</Text>
          <Text style={styles.locValue} numberOfLines={1}>
            {location === DEFAULT_LOCATION ? t("home.setLocation") : location}
          </Text>
          <Feather name="chevron-down" size={16} color={colors.onSurfaceSecondary} />
        </Pressable>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: spacing.xxl }}
      >
        {/* Hero Banner */}
        <View style={styles.heroWrap}>
          <Pressable testID="fresh-groceries-banner" accessibilityRole="button" onPress={() => router.push("/(tabs)/categories")} style={styles.hero}>
            <Image
              source="https://images.unsplash.com/photo-1542838132-92c53300491e?crop=entropy&cs=srgb&fm=jpg&w=1200&q=80"
              style={styles.heroImage}
              contentFit="cover"
            />
            <LinearGradient
              colors={["#D9F5DF", "#D9F5DFD9", "#D9F5DF12"]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.heroContent}>
              <Text style={styles.heroTitle}>Fresh Groceries</Text>
              <Text style={styles.heroTitle}><Text style={styles.heroRed}>& Delicious Food</Text></Text>
              <Text style={styles.heroSub}>Fruits • Vegetables • Daily Essentials</Text>
              <Text style={styles.heroSub}> & Restaurant Favorites</Text>
              <View style={styles.heroCta}>
                <Text style={styles.heroCtaText}>Shop Now</Text>
                <Feather name="arrow-right" size={14} color="#FFFFFF" />
              </View>
            </View>
          </Pressable>
          <View style={styles.carouselDots} accessibilityLabel="Promotional banners">
            {[0,1,2,3,4].map((dot) => <View key={dot} style={[styles.carouselDot, dot === 0 && styles.carouselDotActive]} />)}
          </View>
        </View>

        {/* Four separate discovery entry points; Shopping and Restaurant remain separate routes. */}
        <View style={styles.modeGrid}>
          <ModeCard testID="online-shops-card" title="Online Shops" subtitle="Shop online" icon="shopping-bag" onPress={() => router.push("/shops?type=online")} />
          <ModeCard testID="offline-shops-card" title="Offline Shops" subtitle="Local stores" icon="shopping-cart" onPress={() => router.push("/shops?type=offline")} />
          <ModeCard testID="restaurant-mode-card" title="Restaurants" subtitle="Food & dining" icon="coffee" onPress={() => router.push("/restaurant")} />
          <ModeCard testID="home-services-card" title="Home Services" subtitle="Help at home" icon="tool" onPress={() => router.push("/services")} />
        </View>

        {/* Request Anything */}
        <View style={styles.requestWrap}>
          <Pressable
            testID="request-anything-card"
            onPress={() => router.push("/request")}
            style={styles.requestCard}
          >
            <View style={styles.requestLeft}>
              <View style={styles.requestIcon}>
                <Feather name="package" size={22} color={colors.onBrandPrimary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.requestTitle}>Request Anything</Text>
                <Text style={styles.requestSub}>Need something? We’ll get it for you!</Text>
                <View style={styles.requestOptions}>
                  { ["Grocery", "Pickup", "Drop", "Custom Errand"].map((option) => (
                    <Text key={option} style={styles.requestOption}>✓ {option}</Text>
                  ))}
                </View>
              </View>
            </View>
            <View style={styles.requestArrow}><Feather name="arrow-right" size={20} color="#FFFFFF" /></View>
          </Pressable>
        </View>

        {/* Grocery Categories */}
        <SectionHeader title={t("home.shopByCategory")} onSeeAll={() => router.push("/(tabs)/categories")} />
        <FlatList
          data={["fruits-veggies", "dairy-breakfast", "snacks", "beverages", "bakery", "personal-care"]
            .map((id) => CATEGORIES.find((category) => category.id === id))
            .filter((category): category is (typeof CATEGORIES)[number] => Boolean(category))}
          keyExtractor={(c) => c.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}
          renderItem={({ item }) => (
            <Pressable
              testID={`home-cat-${item.id}`}
              onPress={() => router.push(`/category/${item.id}`)}
              style={[styles.catTile, { backgroundColor: item.tint }]}
            >
              <Image source={item.image} style={styles.catImage} contentFit="cover" />
              <Text style={styles.catName} numberOfLines={2}>
                {{
                  "fruits-veggies": "Fruits & Vegetables",
                  "dairy-breakfast": "Dairy & Breakfast",
                  snacks: "Snacks & Munchies",
                  beverages: "Beverages",
                  bakery: "Bakery",
                  "personal-care": "Personal Care",
                }[item.id] ?? item.name}
              </Text>
            </Pressable>
          )}
        />

        {/* Quick Delivery */}
        <View style={styles.quickHeader}>
          <View style={styles.quickBadge}>
            <Feather name="zap" size={12} color={colors.onBrandSecondary} />
            <Text style={styles.quickBadgeText}>{t("home.minBadge")}</Text>
          </View>
          <Text style={styles.quickTitle}>{t("home.quickDelivery")}</Text>
        </View>
        <FlatList
          data={QUICK_DELIVERY_PRODUCTS}
          keyExtractor={(p) => p.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}
          renderItem={({ item }) => <ProductCard product={item} width={160} />}
        />

        {/* Popular Products */}
        <SectionHeader title={t("home.popular")} onSeeAll={() => router.push("/(tabs)/categories")} />
        <View style={styles.popularGrid}>
          {POPULAR_PRODUCTS.map((p) => (
            <View key={p.id} style={styles.gridItem}>
              <ProductCard product={p} />
            </View>
          ))}
        </View>

        {/* Home Services */}
        <SectionHeader title={t("home.homeServices")} onSeeAll={() => router.push("/services")} />
        <FlatList
          data={SERVICES.slice(0, 4)}
          keyExtractor={(s) => s.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}
          renderItem={({ item }) => (
            <Pressable
              testID={`home-service-${item.id}`}
              onPress={() => router.push("/services")}
              style={styles.serviceCard}
            >
              <Image source={item.image} style={styles.serviceImg} contentFit="cover" />
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceTitle} numberOfLines={1}>
                  {item.title}
                </Text>
                <Text style={styles.serviceTag} numberOfLines={1}>
                  {item.tagline}
                </Text>
                <Text style={styles.servicePrice}>{item.price}</Text>
              </View>
            </Pressable>
          )}
        />

      </ScrollView>

      {/* Location modal */}
      <Modal
        visible={locModalOpen}
        animationType="slide"
        transparent
        onRequestClose={() => setLocModalOpen(false)}
      >
        <Pressable style={styles.modalBackdrop} onPress={() => setLocModalOpen(false)} />
        <View style={[styles.modalSheet, { paddingBottom: insets.bottom + spacing.lg }]}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>{t("home.whereDeliver")}</Text>
          <Text style={styles.modalSub}>{t("home.whereDeliverSub")}</Text>
          <TextInput
            testID="location-input"
            value={locInput}
            onChangeText={setLocInput}
            placeholder={t("home.locationExample")}
            placeholderTextColor={colors.muted}
            style={styles.modalInput}
            autoFocus
          />
          <Pressable
            testID="location-save-btn"
            onPress={() => {
              setLocation(locInput);
              setLocModalOpen(false);
            }}
            style={styles.modalBtn}
          >
            <Text style={styles.modalBtnText}>{t("home.saveLocation")}</Text>
          </Pressable>
        </View>
      </Modal>
    </View>
  );
}

function ModeCard({
  testID, title, subtitle, icon, onPress,
}: {
  testID: string; title: string; subtitle: string;
  icon: React.ComponentProps<typeof Feather>["name"]; onPress: () => void;
}) {
  const styles = useStyles();
  const { colors } = useTheme();
  const cardTint = title === "Offline Shops" ? "#FBF8DF" : title === "Restaurants" ? "#FFF0EF" : "#DFF7EA";
  return (
    <Pressable testID={testID} accessibilityRole="button" onPress={onPress} style={[styles.modeCard, { backgroundColor: cardTint }]}>
      <View style={styles.modeIcon}>
        <Feather name={icon} size={25} color={colors.brandPrimary} />
      </View>
      <View style={styles.modeCopy}>
        <Text style={styles.modeTitle}>{title}</Text>
        <Text style={styles.modeSubtitle}>{subtitle}</Text>
      </View>
      <View style={styles.modeArrow}><Feather name="arrow-right" size={16} color="#FFFFFF" /></View>
    </Pressable>
  );
}

function SectionHeader({ title, onSeeAll }: { title: string; onSeeAll?: () => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {onSeeAll && (
        <Pressable onPress={onSeeAll} hitSlop={10}>
          <Text style={[styles.seeAll, { color: colors.brandPrimary }]}>{t("home.seeAll")}</Text>
        </Pressable>
      )}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    backgroundColor: colors.brandHeader,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  topRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  brandLogoWrap: { flex: 1, maxWidth: 180, alignItems: "flex-start" },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 6 },
  headerAction: { width: 32, height: 32, borderRadius: 18, backgroundColor: "#FFFFFFE8", alignItems: "center", justifyContent: "center" },
  headerAccountAction: { backgroundColor: colors.brandForest },
  logoWrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  logoBadge: {
    width: 32,
    height: 32,
    borderRadius: radius.md,
    backgroundColor: colors.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
  },
  brand: {
    fontSize: 20,
    fontWeight: "800",
    color: colors.onSurface,
    letterSpacing: -0.3,
  },
  tagline: {
    fontSize: 11,
    color: colors.muted,
    marginTop: -2,
  },
  searchArea: {
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.xs,
  },
  locRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    paddingHorizontal: spacing.xs,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  locLabel: { fontSize: 10, color: colors.muted, fontWeight: "600", letterSpacing: 0.2 },
  locValue: { flex: 1, fontSize: 12, color: colors.onSurface, fontWeight: "600" },
  searchRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  searchBar: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    backgroundColor: "#FFFFFF",
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: Platform.OS === "ios" ? 14 : 12,
    borderWidth: 1,
    borderColor: colors.borderStrong,
  },
  filterButton: {
    width: 46, height: 46, borderRadius: radius.md,
    backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: colors.borderStrong,
    alignItems: "center", justifyContent: "center",
  },
  searchPlaceholder: {
    color: colors.muted,
    fontSize: 14,
  },
  heroWrap: { paddingHorizontal: spacing.lg, marginTop: spacing.lg },
  hero: {
    height: 196,
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: "#DDF5DF",
    justifyContent: "center",
  },
  heroImage: { position: "absolute", right: 0, top: 0, bottom: 0, width: "66%", height: "100%" },
  heroContent: {
    width: "74%",
    padding: spacing.md,
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 2,
  },
  heroRed: { color: "#EF202B" },
  carouselDots: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 7, paddingTop: spacing.sm },
  carouselDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#BFE6D1" },
  carouselDotActive: { backgroundColor: colors.brandForest, width: 10, height: 10 },
  heroPill: {
    backgroundColor: colors.brandSecondary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  heroPillText: {
    fontSize: 10,
    fontWeight: "800",
    color: colors.onBrandSecondary,
    letterSpacing: 0.5,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.brandForest,
    lineHeight: 25,
  },
  heroSub: { fontSize: 11, color: colors.brandForest, lineHeight: 15 },
  heroCta: {
    marginTop: spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    backgroundColor: "#F21D2B",
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
  },
  heroCtaText: { fontSize: 13, fontWeight: "700", color: "#FFFFFF" },
  modeGrid: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.md,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.md,
  },
  modeCard: {
    flexBasis: "47%", flexGrow: 1, minHeight: 96,
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    padding: spacing.sm, gap: spacing.sm,
    borderRadius: radius.lg, backgroundColor: "#DFF7EA",
    borderWidth: 1, borderColor: "#C6EFDD",
  },
  modeIcon: {
    width: 52, height: 58, borderRadius: radius.md,
    backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center",
  },
  modeCopy: { flex: 1, gap: 4 },
  modeArrow: { width: 26, height: 26, borderRadius: 14, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" },
  modeTitle: { fontSize: 14, fontWeight: "800", color: colors.brandForest },
  modeSubtitle: { fontSize: 11, color: colors.onSurfaceSecondary },
  sectionHeader: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: colors.onSurface,
  },
  seeAll: { fontSize: 13, fontWeight: "700" },
  catTile: {
    width: 96,
    borderRadius: radius.lg,
    padding: spacing.sm,
    alignItems: "center",
    gap: spacing.xs,
  },
  catImage: {
    width: 68,
    height: 68,
    borderRadius: radius.md,
  },
  catName: {
    fontSize: 11,
    fontWeight: "600",
    color: colors.onSurface,
    textAlign: "center",
  },
  quickHeader: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
    gap: spacing.sm,
  },
  quickBadge: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: colors.brandSecondary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  quickBadgeText: {
    fontSize: 10,
    fontWeight: "800",
    color: colors.onBrandSecondary,
    letterSpacing: 0.5,
  },
  quickTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  popularGrid: {
    paddingHorizontal: spacing.lg,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.md,
  },
  gridItem: {
    flexBasis: "48%",
    flexGrow: 1,
    maxWidth: "48.5%",
  },
  serviceCard: {
    width: 220,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  serviceImg: {
    width: "100%",
    height: 110,
    backgroundColor: colors.surfaceTertiary,
  },
  serviceInfo: { padding: spacing.md, gap: 2 },
  serviceTitle: { fontSize: 14, fontWeight: "700", color: colors.onSurface },
  serviceTag: { fontSize: 12, color: colors.muted },
  servicePrice: {
    fontSize: 13,
    color: colors.brandPrimary,
    fontWeight: "700",
    marginTop: 4,
  },
  requestWrap: { paddingHorizontal: spacing.lg, marginTop: spacing.xl },
  requestCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: colors.brandTertiary,
    borderWidth: 1,
    borderColor: colors.brandPrimary + "33",
    gap: spacing.md,
  },
  requestLeft: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  requestIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
  },
  requestTitle: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.onSurface,
  },
  requestSub: { fontSize: 12, color: colors.onSurfaceSecondary, marginTop: 2 },

  // Modal
  modalBackdrop: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  modalSheet: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    gap: spacing.md,
  },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    alignSelf: "center",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: colors.onSurface,
  },
  modalSub: { fontSize: 13, color: colors.muted, marginTop: -spacing.sm },
  modalInput: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: Platform.OS === "ios" ? 14 : 12,
    fontSize: 15,
    color: colors.onSurface,
  },
  modalBtn: {
    backgroundColor: colors.brandPrimary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: "center",
  },
  modalBtnText: { fontSize: 15, fontWeight: "800", color: colors.onBrandPrimary },
}));
