import { storage } from '@/src/utils/storage';
import { api, TOKEN_KEY } from '@/src/lib/api';
import { FoodItem, findRestaurant } from './data';
export type RestaurantCartLine = { restaurantId:string; itemId:string; quantity:number; isLive?:boolean; itemName?:string; itemDescription?:string; unitPrice?:number; imageUrl?:string; restaurantName?:string; deliveryFee?:number; taxRate?:number; variantId?:string; addOnIds?:string[]; instructions?:string };
const KEY='@comein_restaurant_cart_v1';
export async function readRestaurantCart():Promise<RestaurantCartLine[]> {
 const raw=await storage.getItem<string>(KEY, '[]'); let local:RestaurantCartLine[]=[];
 try { const parsed=JSON.parse(raw ?? '[]'); local=Array.isArray(parsed) ? parsed.filter((x:any)=>x&&typeof x.restaurantId==='string'&&typeof x.itemId==='string'&&Number.isInteger(x.quantity)&&x.quantity>0) : []; } catch { local=[]; }
 const token=await storage.secureGet<string>(TOKEN_KEY,'');
 if(token){try{const server=await api.get<any>('/restaurant/cart');if(server?.items?.length){const live:RestaurantCartLine[]=server.items.map((x:any)=>({restaurantId:server.restaurant_id,itemId:x.menu_item_id,quantity:x.quantity,isLive:true,itemName:x.name,unitPrice:Number(x.price),imageUrl:x.image_url,itemDescription:x.description,variantId:x.variant_id,addOnIds:x.add_on_ids||[],instructions:x.instructions||'',restaurantName:server.restaurant_name,deliveryFee:Number(server.delivery_fee||0),taxRate:Number(server.tax_rate??5)}));await storage.setItem(KEY,JSON.stringify(live));return live;}}catch{/* offline: retain device-local cart */}}
 return local;
}
export async function writeRestaurantCart(lines:RestaurantCartLine[]) {
 await storage.setItem(KEY,JSON.stringify(lines));
 const token=await storage.secureGet<string>(TOKEN_KEY,'');
 if(token){try{if(lines.length===0){await api.del('/restaurant/cart');}else if(lines.every(x=>x.isLive)){await api.put('/restaurant/cart',{restaurant_id:lines[0].restaurantId,items:lines.map(x=>({menu_item_id:x.itemId,quantity:x.quantity,variant_id:x.variantId,add_on_ids:x.addOnIds||[],instructions:x.instructions||''}))});}}catch{/* local cart remains available; checkout revalidates against server */}}
}
export type CalculatedCartRow = {
  restaurantId:string; itemId:string; quantity:number; restaurant:any; item:any; lineTotal:number; unitPrice:number;
  isLive?:boolean; itemName?:string; itemDescription?:string; imageUrl?:string; restaurantName?:string; deliveryFee?:number; taxRate?:number; variantId?:string; addOnIds?:string[]; instructions?:string;
};
export function calculateCart(lines:RestaurantCartLine[]): {rows:CalculatedCartRow[];subtotal:number;delivery:number;tax:number;total:number} {
 const rows:CalculatedCartRow[]=[];
 for(const line of lines){
   const localRestaurant=findRestaurant(line.restaurantId);
   const localItem=localRestaurant?.menu.find(m=>m.id===line.itemId);
   if(localRestaurant&&localItem){rows.push({...line,restaurant:localRestaurant,item:localItem,lineTotal:localItem.price*line.quantity,unitPrice:localItem.price,itemName:localItem.name,imageUrl:localItem.image});continue;}
   if(line.isLive&&line.itemName&&typeof line.unitPrice==='number'){
     rows.push({...line,restaurant:{id:line.restaurantId,name:line.restaurantName||'Restaurant',fee:line.deliveryFee||0,taxRate:line.taxRate??5},item:{id:line.itemId,name:line.itemName,description:line.itemDescription||'',price:line.unitPrice,vegetarian:false,image:line.imageUrl||''},lineTotal:line.unitPrice*line.quantity,unitPrice:line.unitPrice});
   }
 }
 const subtotal=rows.reduce((sum,row)=>sum+row.lineTotal,0);
 const delivery=rows.length?Math.max(...rows.map(row=>Number(row.restaurant.fee||0))):0;
 const tax=rows.reduce((sum,row)=>sum+row.lineTotal*(Number(row.restaurant.taxRate??5)/100),0);
 const roundedTax=Math.round(tax*100)/100;
 return {rows,subtotal:Math.round(subtotal*100)/100,delivery,tax:roundedTax,total:Math.round((subtotal+delivery+roundedTax)*100)/100};
}

export type { FoodItem };
