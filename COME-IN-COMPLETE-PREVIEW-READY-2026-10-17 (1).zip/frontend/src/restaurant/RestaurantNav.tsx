import Feather from '@react-native-vector-icons/feather';
import { usePathname, useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { restaurantTheme as t } from './theme';
const items=[['/restaurant','Home','home'],['/restaurant/categories','Categories','grid'],['/restaurant/search','Search','search'],['/restaurant/cart','Cart','shopping-cart'],['/restaurant/account','Account','user']] as const;
export function RestaurantNav(){const router=useRouter();const path=usePathname();return <View style={s.bar}>{items.map(([route,label,icon])=>{const active=path===route;return <Pressable key={route} accessibilityRole="button" accessibilityLabel={label} onPress={()=>router.push(route as never)} style={s.item}><Feather name={icon} size={18} color={active?t.onPrimary:'#F4C5D5'}/><Text style={[s.label,active&&s.active]}>{label}</Text></Pressable>})}</View>}
const s=StyleSheet.create({bar:{flexDirection:'row',justifyContent:'space-around',backgroundColor:t.accent,paddingVertical:10,paddingHorizontal:3,borderRadius:18},item:{alignItems:'center',gap:4,flex:1},label:{color:'#F4C5D5',fontSize:9},active:{color:t.onPrimary,fontWeight:'800'}});
