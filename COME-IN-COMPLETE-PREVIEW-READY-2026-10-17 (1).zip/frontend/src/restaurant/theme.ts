/** Restaurant Mode tokens. Intentionally isolated from the Shopping Mode theme. */
export const restaurantTheme = {
  background: "#FFF1F5",
  surface: "#FFFFFF",
  surfaceSoft: "#FCE8ED",
  surfaceAccent: "#F7C6D5",
  primary: "#D81B60",
  primaryPressed: "#B91550",
  onPrimary: "#FFFFFF",
  accent: "#A80F49",
  text: "#35252B",
  textMuted: "#806B72",
  border: "#EBC9D3",
  divider: "#F1DCE2",
  error: "#B42335",
  radiusSm: 10,
  radiusMd: 16,
  radiusLg: 22,
  radiusXl: 28,
  spacingSm: 8,
  spacingMd: 12,
  spacingLg: 20,
  spacingXl: 28,
} as const;

export type RestaurantTheme = typeof restaurantTheme;
