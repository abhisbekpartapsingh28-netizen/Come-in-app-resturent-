import { api } from '@/src/lib/api';
export type LiveRestaurant={id:string;name:string;description:string;cuisines:string[];phone?:string;address:string;city:string;image_url?:string;delivery_available:boolean;pickup_available:boolean;delivery_fee:number;tax_rate:number;min_order:number;estimated_minutes:number;rating:number;review_count:number;available?:boolean;status?:string};
export type LiveMenuItem={id:string;restaurant_id:string;name:string;description:string;category:string;price:number;image_url?:string;available:boolean;vegetarian?:boolean;variants?:{id:string;name:string;price:number}[];add_ons?:{id:string;name:string;price:number}[]};
export type RestaurantFilters={cuisine?:string;minRating?:number;maxDeliveryFee?:number;city?:string};
export const listLiveRestaurants=(q='',filters:RestaurantFilters={})=>{const params=new URLSearchParams();if(q.trim())params.set('q',q.trim());if(filters.cuisine&&filters.cuisine!=='All')params.set('cuisine',filters.cuisine);if(filters.minRating!==undefined)params.set('min_rating',String(filters.minRating));if(filters.maxDeliveryFee!==undefined)params.set('max_delivery_fee',String(filters.maxDeliveryFee));if(filters.city)params.set('city',filters.city);const query=params.toString();return api.get<LiveRestaurant[]>(`/restaurants${query?`?${query}`:''}`,false)};
export const getLiveRestaurant=(id:string)=>api.get<LiveRestaurant>(`/restaurants/${encodeURIComponent(id)}`,false);
export const getLiveMenu=(id:string,q='')=>api.get<LiveMenuItem[]>(`/restaurants/${encodeURIComponent(id)}/menu${q?`?q=${encodeURIComponent(q)}`:''}`,false);
export const createLiveOrder=(body:unknown)=>api.post<any>('/restaurant/orders',body,true);
export const getMyRestaurantOrders=()=>api.get<any[]>('/restaurant/orders/mine',true);
