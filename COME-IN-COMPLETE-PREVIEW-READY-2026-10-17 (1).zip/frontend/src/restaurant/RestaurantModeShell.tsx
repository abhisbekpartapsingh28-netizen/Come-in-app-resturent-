import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import type { ReactNode } from "react";
import { Pressable, ScrollView, StatusBar, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { restaurantTheme as theme } from "@/src/restaurant/theme";

type Props = {
  children: ReactNode;
  title?: string;
  subtitle?: string;
};

/** Shared, restaurant-only shell. Does not mutate or import Shopping Mode theme tokens. */
export function RestaurantModeShell({
  children,
  title = "Restaurants",
  subtitle = "Discover food around you",
}: Props) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={theme.background} />
      <View style={[styles.header, { paddingTop: insets.top + theme.spacingSm }]}>
        <View style={styles.headerRow}>
          <View style={styles.brandMark}>
            <Text style={styles.brandMarkText}>C</Text>
            <View style={styles.brandDot} />
          </View>
          <View style={styles.brandTextWrap}>
            <Text style={styles.brand}>Come-In</Text>
            <Text style={styles.brandSub}>YOUR TOWN, AT YOUR DOOR</Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Return to Come-In Shopping Home"
            testID="restaurant-back-to-shopping"
            onPress={() => router.replace("/(tabs)")}
            style={({ pressed }) => [styles.backButton, pressed && styles.pressed]}
          >
            <Feather name="arrow-left" size={16} color={theme.accent} />
            <Text style={styles.backLabel}>Shopping</Text>
          </Pressable>
        </View>
        <Text style={styles.pageTitle}>{title}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + theme.spacingXl }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {children}
      </ScrollView>
    </View>
  );
}

export { theme as restaurantTheme };

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.background },
  header: {
    paddingHorizontal: theme.spacingLg,
    paddingBottom: theme.spacingMd,
    backgroundColor: theme.surfaceSoft,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
  },
  headerRow: { flexDirection: "row", alignItems: "center", gap: theme.spacingSm },
  brandMark: {
    width: 40,
    height: 40,
    borderRadius: 13,
    backgroundColor: theme.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  brandMarkText: { color: theme.onPrimary, fontSize: 25, fontWeight: "900", fontStyle: "italic" },
  brandDot: { position: "absolute", top: 7, right: 7, width: 6, height: 6, borderRadius: 3, backgroundColor: "#FFD85A" },
  brandTextWrap: { flex: 1 },
  brand: { color: theme.primary, fontSize: 19, fontWeight: "900", letterSpacing: -0.5 },
  brandSub: { color: theme.textMuted, fontSize: 7, fontWeight: "800", letterSpacing: 0.65, marginTop: 1 },
  backButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingVertical: 9,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: theme.border,
    backgroundColor: theme.surface,
  },
  pressed: { opacity: 0.75 },
  backLabel: { color: theme.accent, fontSize: 11, fontWeight: "800" },
  pageTitle: { color: theme.text, fontSize: 22, lineHeight: 28, fontWeight: "900", marginTop: theme.spacingMd },
  subtitle: { color: theme.textMuted, fontSize: 12, marginTop: 2 },
  scroll: { flex: 1 },
  content: { padding: theme.spacingMd, gap: theme.spacingLg },
});
