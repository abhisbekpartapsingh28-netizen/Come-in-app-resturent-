// Come In — Auth context.
//
// Loads a persisted bearer token on mount, exposes:
//   - user: null (loading) | undefined (not logged in) | User
//   - login, register, logout, refresh
//
// Token is stored via the shared storage util (web = IndexedDB, native = secure).

import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

import { api, TOKEN_KEY } from "@/src/lib/api";
import { storage } from "@/src/utils/storage";

export type Role = "customer" | "shopkeeper" | "admin";

export type User = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: Role;
};

type AuthState = {
  user: User | null | undefined; // null = loading, undefined = anonymous
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (name: string, email: string, password: string, phone?: string) => Promise<User>;
  logout: () => Promise<void>;
  refresh: () => Promise<User | undefined>;
  patchUser: (patch: Partial<User>) => void;
};

const AuthContext = createContext<AuthState | undefined>(undefined);

async function saveToken(token: string) {
  const saved = await storage.secureSet(TOKEN_KEY, token);
  if (!saved) {
    throw new Error('Your account was authenticated, but this device could not save the session securely. Check storage permissions and try again.');
  }
}

async function clearToken() {
  await storage.secureRemove(TOKEN_KEY);
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null | undefined>(null);

  const refresh = useCallback(async (): Promise<User | undefined> => {
    try {
      const token = await storage.secureGet<string>(TOKEN_KEY, "");
      if (!token || typeof token !== "string") {
        setUser(undefined);
        return undefined;
      }
      const me = await api.get<User>("/auth/me");
      setUser(me);
      return me;
    } catch (error) {
      // A rejected/expired token should be removed; transient network failures
      // must not destroy the persisted session so it can recover on reconnect.
      if (error && typeof error === "object" && "status" in error && error.status === 401) {
        await storage.secureRemove(TOKEN_KEY);
        setUser(undefined);
        return undefined;
      }
      // Keep an already-hydrated user signed in through transient network/5xx errors.
      // On cold start, finish loading as anonymous while retaining the persisted token.
      setUser((current) => (current && typeof current === "object" ? current : undefined));
      return undefined;
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const login = useCallback(async (email: string, password: string) => {
    const res = await api.post<{ token: string; user: User }>(
      "/auth/login",
      { email, password },
      false,
    );
    await saveToken(res.token);
    setUser(res.user);
    return res.user;
  }, []);

  const register = useCallback(
    async (name: string, email: string, password: string, phone?: string) => {
      const res = await api.post<{ token: string; user: User }>(
        "/auth/register",
        { name, email, password, phone },
        false,
      );
      await saveToken(res.token);
      setUser(res.user);
      return res.user;
    },
    [],
  );

  const logout = useCallback(async () => {
    await clearToken();
    setUser(undefined);
  }, []);

  const patchUser = useCallback((patch: Partial<User>) => {
    setUser((prev) => (prev && typeof prev === "object" ? { ...prev, ...patch } : prev));
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, loading: user === null, login, register, logout, refresh, patchUser }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside <AuthProvider>");
  return ctx;
}
