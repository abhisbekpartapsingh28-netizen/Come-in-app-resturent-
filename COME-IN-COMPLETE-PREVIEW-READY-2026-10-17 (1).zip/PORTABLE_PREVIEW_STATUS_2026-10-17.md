# COME-IN Portable Preview Preparation — 2026-10-17

## Source and scope

Prepared from `COME-IN-COMPLETE-PROJECT-BACKUP-2026-10-16.zip` because the separately named recovery directory was not present in this environment. Original ZIPs were not overwritten. This is the existing app source, not a rebuild.

## Changes in this preparation

- `scripts/replit-install.sh`: now uses the package manager declared in `frontend/package.json` (Yarn/Corepack) instead of running npm against a Yarn-declared project; exits with clear messages on install failures.
- `scripts/replit-run.sh`: frontend auto-install follows the declared Yarn/Corepack package manager and reports a clear error if unavailable. Backend remains optional for UI startup and is not mocked.
- `README.md`: adds import, Replit Preview, Emergent, environment, testing, and troubleshooting steps, with unverified platform-specific claims clearly qualified.
- `.env.example`: adds safe root-level placeholder variable reference; no credentials are included.

## Checks performed

- Existing consolidated source ZIP: `unzip -t` passed.
- Backend tests: `25 passed, 23 skipped, 0 failed` (`cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests`).
- `node --version`: v22.16.0; `npm --version`: 10.9.2; Python: 3.13.5.
- Registry check: DNS lookup for `registry.npmjs.org` and `pypi.org` returned no addresses; `curl -I https://registry.npmjs.org/` failed with `curl: (6) Could not resolve host: registry.npmjs.org`.
- No frontend dependency install was attempted because registry DNS was unavailable; no repeated retries were performed.
- Frontend typecheck, export/build, HTTP root route, and live Replit/Emergent Preview remain unverified.

## Important package-manager note

The source declares Yarn 1.22.22 in `frontend/package.json`, but the source ZIP contains neither `yarn.lock` nor `package-lock.json`. A lockfile was not fabricated because registry access was unavailable. The install script uses the declared Yarn manager and will create a lockfile only if the package manager resolves dependencies successfully in the target workspace.

## Remaining blocker

A workspace with working package-registry DNS and Corepack/Yarn must run `bash ./scripts/replit-install.sh`, then start the existing `.replit` Run command and verify Preview port 3000. This local container does not have direct authenticated Replit/Emergent workspace access.
