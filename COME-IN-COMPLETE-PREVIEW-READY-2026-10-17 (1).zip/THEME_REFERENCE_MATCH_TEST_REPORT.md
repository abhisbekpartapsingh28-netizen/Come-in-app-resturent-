# COME-IN — Shopping Mode Reference-Match Implementation & Verification

**Date:** 2026-10-15  
**Scope:** Existing COME-IN project; Shopping Mode only. No Replit launch, no manual app launch, no production deployment, no payment activity.

## Summary

Updated the existing Shopping Mode home toward the supplied 944×2048 reference screenshot while preserving the existing Expo Router architecture, Shopping Mode routes/cart, and dedicated Restaurant Mode route/cart. The existing full COME-IN logo asset remains in use. The existing project backup was not overwritten.

## Theme implementation

- Yellow header with existing full horizontal COME-IN logo and four compact controls.
- Header language control navigates to the existing `/language` route.
- Microphone icon opens the existing Search screen. **Speech-to-text/OS microphone capture is not implemented** in the current project and was not fabricated; this control is a search entry point only.
- Bell control navigates to existing `/orders`; profile control navigates to the existing Account tab.
- Existing delivery-location selector retained so location editing still works.
- Search field and filter button retained; filter opens Categories.
- Promotional banner now uses the “Fresh Groceries & Delicious Food” copy, green produce imagery, red “Shop Now” CTA and pagination dots. The CTA opens Categories.
- Four discovery cards are in the requested order: Online Shops, Offline Shops, Restaurants, Home Services. Their existing routes are retained, with Online/Offline query filters preserved.
- Request Anything section is placed before Shop by Category and includes Grocery, Pickup, Drop, and Custom Errand copy. The banner routes to the existing request screen.
- Home category row is ordered: Fruits & Vegetables, Dairy & Breakfast, Snacks & Munchies, Beverages, Bakery, Personal Care. The full category screen and original categories remain; a Bakery category and a sample local-catalog bread item were added because the source catalog did not contain a Bakery category, making that requested tile otherwise non-functional.
- Existing Home, Categories, Search, Cart, Account navigation remains. Existing cart badge logic is preserved.
- Mint surfaces and forest-green accents are updated in the app theme tokens. Restaurant Mode has its own components/theme and no Restaurant Mode source files were edited in this pass.

## Files changed in this pass

1. `frontend/app/(tabs)/index.tsx` — Shopping home header controls, banner copy/layout, discovery cards, Request Anything placement, category ordering/labels, responsive card layout.
2. `frontend/src/theme.ts` — mint surface, yellow header and green accent/border token values.
3. `frontend/src/data/catalog.ts` — Bakery category and sample local-catalog bread item to give the explicitly requested category a working destination.
4. `backend/tests/test_frontend_contracts.py` — updated static contract assertions for the new home category ordering and header/banner controls; updated theme token assertions.
5. `THEME_REFERENCE_MATCH_TEST_REPORT.md` — this report.

No backend application code, API contracts, database schemas, authentication, payments, Restaurant Mode screens, or roadmap tasks were changed. The existing 22-task roadmap is retained; no Task 23 was added.

## Tests actually run

| Check | Status | Command / details |
|---|---|---|
| Backend + frontend static contract regression suite | **Passed with skips** | `cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests` — **22 passed, 23 skipped, 0 failed**. The 23 tests require a configured remote integration test base URL / isolated test deployment and test-only services/credentials in some cases. |
| Python syntax | **Passed** | `python -m py_compile backend/server.py backend/restaurant_pricing.py` (also run from `backend` as `python -m py_compile server.py restaurant_pricing.py`). |
| Frontend TypeScript typecheck | **Blocked** | `cd frontend && npm run typecheck` — exit 2. `node_modules` and `expo/tsconfig.base` are absent; unresolved Expo/React Native modules make this an invalid environment run, not a code-pass result. |
| Frontend lint | **Blocked** | `cd frontend && npm run lint` — exit 127, `expo: not found`. |
| Frontend web build | **Blocked** | `cd frontend && npm run build:web` — exit 127, `expo: not found`. |
| Browser/device screenshot comparison | **Not run / blocked by constraints** | The app was not launched as requested, and dependencies are absent. No rendered screenshot was captured; therefore no claim of pixel-perfect matching is made. |
| Restaurant Mode visual regression | **Not runtime-verified** | No Restaurant Mode files were edited, and static route/cart-separation tests passed; no app screenshot or runtime comparison was possible. |
| ZIP integrity | **Passed** | `unzip -t` on the produced archive reports no compressed-data errors. |

## Visual differences and limitations

- The supplied screenshot contains custom illustrated artwork for the banner and all four discovery cards. The source project did not contain those exact artwork assets. The implementation uses the original COME-IN logo, available catalog/produce imagery, and existing Feather icons rather than pretending to have exact artwork.
- The banner is structurally and typographically reference-oriented but is not pixel-identical to the supplied image; the reference's hand-composed collage/artwork is not present as reusable source assets.
- The header retains the existing location selector as well as the requested controls, so it is taller than the reference. This preserves the existing location-editing behavior.
- The microphone icon opens Search but does not perform speech recognition. Adding real voice recognition would require a supported platform API/permission and implementation beyond the current dependency set.
- No screenshot was rendered or compared, and no 100% visual-match claim is made.

## Packaging hygiene

- Project root inside ZIP: `COME-IN/`.
- Safe `frontend/.env.example` and backend `.env.example` retained.
- Real `.env` files, dependency folders, caches, temporary files, and build outputs excluded.
- Source manifests and assets retained. The source snapshot does not contain a Yarn/npm/pnpm lockfile; none was fabricated.
- Original ZIP remains a separate backup.
