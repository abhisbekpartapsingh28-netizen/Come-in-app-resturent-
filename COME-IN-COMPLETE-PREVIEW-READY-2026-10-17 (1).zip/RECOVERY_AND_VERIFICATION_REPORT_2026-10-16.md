# COME-IN Recovery & Verification Report — 2026-10-16

## Scope and source selection

- Selected source: `COME-IN-Replit-Preview-Configured-Followup-2026-10-15.zip` (125 files; SHA-256 `f07610b77611f3b85a6898b5881252fd8d3f7a43e2c56fa75706c2746eb3a271`).
- Reason: it is the newer of the two supplied Replit-preview-configured archive variants; comparison showed the same file set, with only `REPLIT_PREVIEW_READINESS_REPORT_2026-10-15.md` and `scripts/replit-run.sh` differing from the preceding configured archive.
- Original ZIPs were not modified. Recovery work was performed in a separate directory.
- No Git repository/history was available in the extracted selected source.

## Preview finding

The user-provided screenshot says `404 — Not Found` and `This deployment has no previewable artifacts.` That message establishes that the URL opened was not serving a previewable artifact; it does **not** establish that the Expo app itself returned the 404, nor prove the exact Replit workspace workflow state. This environment cannot access the user's live Replit workspace, its Console, or its Preview controls, so the remote root cause and actual Preview status remain unverified.

The checked `.replit` runs `bash ./scripts/replit-run.sh`; it maps local port 3000 to external port 80 and port 8000 to external 8000. The existing run script starts Expo Web on port 3000 and starts FastAPI on 8000 only if `MONGO_URL`, `DB_NAME`, and a non-placeholder `JWT_SECRET` are configured. It does not itself register a deployment artifact. The intended action for development is Replit's project **Run / Preview**, not a public deployment page.

## Dependency/network findings

- Node `v22.16.0`, npm `10.9.2`, Python `3.13.5` are present in this packaging environment.
- `frontend/node_modules` is absent.
- No `yarn.lock` or `package-lock.json` is present; `frontend/package.json` declares Yarn 1.22.22 as package manager.
- At check time, `getent hosts registry.npmjs.org` and `getent hosts pypi.org` returned no addresses. Dependency installation was not attempted/retried because registry DNS was unavailable.
- Frontend build, Expo startup, and HTTP route `/` could not be tested without installed frontend dependencies.
- Backend import/startup and database connectivity were not claimed as verified; required secrets/database are not available here.

## Tests actually run

- `python -m py_compile backend/server.py backend/restaurant_pricing.py` — **passed**.
- From `backend/`: `PYTHONPATH=. python -m pytest -c /dev/null -q tests` — **25 passed, 23 skipped, 0 failed**.
- An initial pytest invocation from the project root (`PYTHONPATH=. python -m pytest -c /dev/null -q backend/tests`) failed during collection because `restaurant_pricing` is imported as a backend-local module. Running the repository's intended test command from `backend/` passed. No source code was changed to hide this invocation-specific issue.
- `python -m pytest -c /dev/null -q tests` from the project root found no tests because the root `tests/` directory contains no collected test cases; backend tests are under `backend/tests/`.
- ZIP integrity and contents are validated separately by the packaging process.

## Preserved feature inventory (source presence, not end-to-end validation)

- Shopping routes/screens present: home, tabs (home/categories/search/cart/account), shops, shop detail, category, product, checkout, delivery address, orders, authentication, language, seller onboarding, admin, and services.
- Restaurant routes/screens present: restaurant home, detail, menu, categories, search, cart, checkout, order confirmation, addresses, account, dashboard, and support.
- Backend source, restaurant pricing, API contract/regression tests, assets/previews, project roadmap, setup docs, and existing configuration are included.
- The source includes claims/checklists for further capabilities in its own roadmap/status documents; this report does not claim that every listed workflow (payments, GPS, notifications, AI/voice integrations, all role workflows, etc.) has been implemented or end-to-end tested.

## Changes in this recovery copy

- Added this evidence-based report.
- Updated `README.md` with tested recovery/test commands and explicit separation of local checks from unverified Replit Preview. Existing source, routes, app design, backend logic, and database schema were not changed for this recovery package.

## Remaining blockers / next action

1. In the actual `Come-In App Preview` Replit workspace, open the project workspace (not a Deployment URL) and press **Run**. This is required to inspect actual Console logs and verify the Preview route; this environment has no authenticated Replit workspace controls.
2. If the install script fails, stop after the first registry error and restore registry/DNS access before retrying.
3. Once dependencies are available, run `bash ./scripts/replit-install.sh`, then `bash ./scripts/replit-run.sh`; check the port-3000 Preview. Configure `MONGO_URL`, `DB_NAME`, `JWT_SECRET`, and browser-reachable `EXPO_PUBLIC_BACKEND_URL` only if backend/API features are to be tested.

## Honest status

- Local backend tests: **25 passed, 23 skipped**.
- Python syntax: **passed**.
- Frontend runtime/build: **blocked by absent dependencies and unavailable registry DNS**.
- Actual Replit Preview: **not verified; live workspace inaccessible from this environment**.
