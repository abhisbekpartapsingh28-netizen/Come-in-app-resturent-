# COME-IN APP — MASTER PROJECT PROMPT

## Project Memory • 22 Main Tasks • Restaurant Mode • Safety • Next Steps

इस प्रॉम्प्ट को पढ़कर Come-In प्रोजेक्ट का संदर्भ समझें। यह चल रहे प्रोजेक्ट की जानकारी और आवश्यकताएँ हैं, नया ऐप शुरू करने का निर्देश नहीं। इसे भविष्य की बातचीत में संदर्भ के रूप में इस्तेमाल करें।

---

## 1. COME-IN क्या है?

Come-In एक स्थानीय शॉपिंग और सेवाओं वाला ऐप है, जिसका उद्देश्य एक ही ऐप में ये चीज़ें उपलब्ध कराना है:

- Online Shops

- Offline Local Shops

- Grocery और Daily Essentials

- Restaurants और Food Ordering

- Home Services

- भविष्य में स्थानीय कारोबार और ग्राहक सुविधा से जुड़े अन्य फीचर

**Restaurants Come-In का मुख्य बिज़नेस हिस्सा है**, कोई छोटा या वैकल्पिक ऐड-ऑन नहीं। हमारा अंतर यह है कि ग्राहक किराना, स्थानीय दुकानें, रेस्टोरेंट और Home Services एक ही ऐप में पा सके।

## 2. काम करने के अनिवार्य नियम

1. इसे मौजूदा प्रोजेक्ट मानें। बिना जाँच के यह न मानें कि ऐप पूरा है या खराब है।

2. किसी नए फीचर पर काम शुरू करने से पहले उपलब्ध प्रोजेक्ट, frontend, backend, API, database, navigation, authentication, cart और मौजूदा स्क्रीन का audit करें।

3. पहले से काम कर रहे फीचर, डेटा और डिज़ाइन को सुरक्षित रखें।

4. मौजूदा स्क्रीन/API/component को सुरक्षित रूप से इस्तेमाल किया जा सकता हो तो डुप्लिकेट न बनाएँ।

5. डेटा मिटाने, database reset/migration, बड़े बदलाव या production deployment से पहले जोखिम समझाएँ और मेरी स्पष्ट अनुमति लें।

6. किसी paid service, API, subscription या hosting cost को मेरी अनुमति के बिना सक्रिय न करें।

7. जो काम वास्तव में नहीं किया, उसे completed, tested या working न बताएं।

8. स्थिति स्पष्ट रूप से बताएँ: Planned / Implemented / Tested / Verified Working / Blocked / Pending।

9. GitHub, ZIP, hosting, Emergent, Replit, API या database का access न हो तो साफ़ बताएँ कि क्या चाहिए।

10. मुझे आसान हिंदी/Hinglish में एक-एक करके निर्देश दें। मैं तकनीकी विशेषज्ञ नहीं हूँ; ज़रूरत हो तो मैं स्क्रीनशॉट भेजूँगा।

11. एक बार में छोटे, नियंत्रित और जाँचने योग्य बदलाव करें। बिना ज़रूरत पूरा ऐप rewrite न करें।

12. पहले मौजूदा काम और backup की स्थिति समझें; उसके बाद ही बदलाव करें।

13. टेस्ट और परिणाम का प्रमाण दें। केवल कोड देखकर runtime success का दावा न करें।

14. कोई नया feature मुख्य roadmap में जोड़ने से पहले मुझसे पूछें।

15. मेरे मुख्य roadmap में **22 काम** हैं। इन्हें अपने-आप 23 या अधिक मुख्य काम न बनाएँ। नीचे बताए गए नए फीचर मौजूदा कामों के subtask हैं।

## 3. Come-In के 22 मुख्य काम

### Phase 1 — Audit

**Task 1: Existing Project Audit**

- वर्तमान ऐप, स्क्रीन, navigation, frontend/backend, API, database और authentication की जाँच।

- कौन-से बटन और workflows वास्तव में काम करते हैं, जाँचें।

- Grocery, online/offline shops, restaurants और Home Services के मौजूदा फीचर पहचानें।

- duplicate routes/components, errors और अधूरे काम नोट करें।

- पहले read-only audit करें; बिना अनुमति fixes न करें।

### Phase 2 — Design और Customer Experience

**Task 2: Theme and Design**

- साफ़, consistent, mobile-friendly डिज़ाइन।

- मुख्य shopping theme: Yellow + Forest Green + Pale Mint।

- rounded cards, readable text, subtle shadows और consistent spacing।

**Task 3: Home Screen and Navigation**

- Home screen, category entry points और bottom navigation।

- Online Shops, Offline Shops, Restaurants और Home Services तक स्पष्ट पहुँच।

- सेक्शन बदलने और वापस आने का आसान रास्ता।

### Phase 3 — Product Catalog और Shopping

**Task 4: Categories and Catalog**

- Grocery, daily essentials, local shops और restaurant/food categories व menu/catalog।

- मौजूदा data model audit करें।

**Task 5: Quantity, Variants and Units**

- product size, weight, quantity, variants और unit selection।

- जहाँ लागू हो, price per unit स्पष्ट करें।

**Task 6: Search and Filters**

- products, shops, restaurants और food items की खोज।

- relevant filters, जैसे category, veg/non-veg, cuisine और availability जहाँ डेटा उपलब्ध हो।

- price comparison के नियम Task 21 से जुड़ें।

### Phase 4 — Cart और Orders

**Task 7: Cart and Checkout**

- सुरक्षित cart, price/stock revalidation और checkout।

- Restaurant cart और grocery/shop cart अलग रहें; गलती से mix न हों।

- checkout, delivery fee और order summary स्पष्ट हों।

**Task 8: Repeat Order**

- पहले के order से items दोबारा चुनना; current price और stock फिर जाँचना।

**Task 9: Out-of-Stock Replacement**

- item unavailable होने पर replacement या removal का विकल्प।

- अनुमति के बिना अनचाहा replacement न करें।

### Phase 5 — Delivery और Customer Support

**Task 10: Live Tracking**

- वास्तविक data/integration होने पर order status/tracking।

- live tracking का दावा तभी करें जब सच में काम करे।

- शुरुआत में restaurant अपनी delivery संभाल सकता है, यदि arrangement स्पष्ट हो।

**Task 11: Order Help and Refund Status**

- order issue, cancellation/help और refund status।

- Shop Call Assistance subtask: shop का phone connect न हो तो ग्राहक Come-In agent/representative से दुकान पर जाकर बात करवाने का अनुरोध कर सके। Operational व्यवस्था पहले तय करनी होगी।

### Phase 6 — Seller Tools और Data

**Task 12: Excel/CSV Price and Stock Import**

- shops के लिए products, price और stock upload/update।

- importer schema audit करें।

- stable product ID से update करें; duplicates न बनाएँ।

- invalid prices, missing names, invalid stock और wrong columns पर errors दिखाएँ।

- पहले test/staging में जाँचें; production data पर बिना अनुमति परीक्षण न करें।

### Phase 7 — Accounts और Operations

**Task 13: Login and Account**

- सुरक्षित login/account, profile और order history।

- mode बदलने पर login/account न खोएँ।

**Task 14: Seller/Shop/Restaurant Panel**

- shop panel में products, prices, availability और orders।

- restaurant partners के लिए menu, item prices, availability और food orders।

- मौजूदा सुविधा को reuse करें।

**Task 15: Admin Panel**

- admin controls, shop/restaurant management, catalog, orders और announcements।

- role permissions जाँचें।

### Phase 8 — Backend, Security और Payments

**Task 16: Backend, Database and Security**

- authentication, authorization, validation, secrets, API access और database rules audit।

- sensitive keys frontend/public repository में न हों।

- user/order data और permissions सुरक्षित हों।

- backup/restore strategy जाँचें; बिना test के backup को recoverable न बताएं।

**Task 17: Payments and Notifications**

- payment status, order status, settlement और refunds।

- provider terms के अनुसार gateway fees समझें।

- push/in-app notifications और backend integration।

- paid integrations या production activation से पहले अनुमति लें।

### Phase 9 — Testing और Launch

**Task 18: Testing and Bug Fixes**

- customer, seller, restaurant, admin और order workflows test करें।

- UI, navigation, API, database और errors जाँचें।

- fix के बाद retest करें।

- read-only audit के दौरान बिना अनुमति implementation न करें।

**Task 19: Production Build and Launch**

- production readiness, configuration, secrets, backup, monitoring और deployment checklist।

- deployment, paid resources या irreversible actions से पहले मेरी स्पष्ट अनुमति।

- recurring costs पहले बताएँ।

### Phase 10 — Advanced Features

**Task 20: Smart Notification System**

- push और in-app notification center।

- order status, offers/promotions, price changes, restocks और app announcements।

- admin announcement approval/targeting और sensible frequency।

- app बंद होने पर push के लिए provider setup, user permission और backend integration जरूरी।

- test के बिना working न बताएं।

**Task 21: Smart Price Comparison**

- एक ही product की अलग-अलग shops में तुलना।

- सही match: brand, pack size, weight, unit और variant।

- उपलब्ध matching offers में सबसे कम verified price पहले highlight करें; अन्य offers भी दिखाएँ।

- stock, distance/delivery और last-updated time तभी दिखाएँ जब वास्तविक data उपलब्ध हो।

- checkout पर price और stock फिर verify करें।

- local shops के Excel/CSV data का उपयोग।

- third-party retailer live API/feed के लिए अनुमति और वास्तविक access जरूरी है; केवल registration से access न मानें।

- external data sources की licensing/access जाँचें; reference data को actual local shop price न कहें।

**Task 22: Home Services Logo/Icon and Tile Integration**

- Home screen पर Home Services tile/icon को मुख्य theme से match करें।

- पहले जाँचें कि existing Home Services flow/destination है या नहीं।

- working flow हो तो reuse करें; duplicate न बनाएँ।

- flow न हो तो gap बताकर implementation से पहले अनुमति लें।

---

## 4. Approved Subtask: Restaurant Mode और Automatic Branding/Theme Switch

यह अलग 23वाँ main task नहीं है। इसे Tasks 2, 3, 4, 6, 7, 10, 14, 17 और 18 के अंतर्गत tracked subtask रखें।

### Restaurant Mode

Come-In के अंदर proper food-ordering experience हो—restaurant listings, menu, food cart, checkout, food orders और जहाँ supported हो delivery status। यह सिर्फ restaurant list नहीं होना चाहिए।

### Automatic theme switching

**Shopping Mode:** Yellow + Forest Green + Pale Mint — grocery, local shops, daily essentials और Home Services।

**Restaurant Mode:** Creamy Red + White + Cream — restaurant listings, food/menu pages, food cart, checkout और food orders। Header, buttons, icons और relevant interface भी restaurant theme से match करें।

जब user Restaurants पर tap करे:

1. Restaurant Mode खुले।

2. theme अपने आप Creamy Red + White + Cream में बदले।

3. Come-In logo/brand की पहचान और मूल shape consistent रहे, लेकिन matching restaurant-mode color variant दिखे।

4. restaurant experience के लिए स्पष्ट navigation हो।

जब user Restaurant Mode में **Come-In Home** दबाए:

1. सामान्य Come-In Shopping Home खुले।

2. theme/logo variant वापस Yellow + Forest Green + Pale Mint हो।

3. user को केवल back button पर निर्भर न रहना पड़े।

### Cart, login और history

- grocery/shop cart और restaurant food cart अलग रहें।

- mode switch से login, account या order history न खोए।

- cart persistence और mode state architecture audit करें।

- navigation और restart के relevant scenarios test करें।

### Branding safety

- एक Come-In brand identity रखें; unrelated second brand न बनाएँ।

- logo का रंग variant बदले, brand identity बनी रहे।

- theme switching का अर्थ native app icon अपने आप बदलना नहीं है; header logo, splash screen और app icon अलग-अलग assets/behavior हो सकते हैं।

- इन सभी को अलग-अलग verify करें।

- यह planned requirement है; implementation/test के बिना complete न कहें।

### Restaurant details

- nearby restaurants, photos/ratings/open hours केवल verified data होने पर।

- menu, prices, veg/non-veg और cuisine filters।

- food cart, checkout, order status।

- restaurant partner panel।

- delivery arrangements और responsibility स्पष्ट करें।

---

## 5. Home Screen, Categories और Splash Screen

मुख्य shopping Home:

- bright yellow header

- forest-green text/icons

- pale mint background

- rounded pastel-green cards

- subtle yellow borders and soft shadows

- Online Shops, Offline Shops, Restaurants और Home Services tiles

- search, promo area और category browsing

- Home, Categories, Search, Cart, Account navigation मौजूदा architecture के अनुसार

Planned grocery categories:

1. Atta, Rice & Dal

2. Dairy & Breakfast

3. Fruits & Vegetables

4. Snacks & Munchies

5. Personal Care

6. Household Essentials

7. Beverages

8. Bakery

9. Frozen Foods

10. Pet Care

11. Baby Care

12. Stationery & Books

13. Electronics & Gadgets

14. Home Decor

15. Tools & Hardware

Planned splash:

- cold start/restart पर Come-In logo/name और tagline।

- मुख्य branding yellow/forest-green; restaurant launch/mode के behavior को existing architecture देखकर तय करें।

- लगभग 2 seconds केवल अगर उचित हो; duplicate flash या blank screen न बने।

- login, cart और order history सुरक्षित रहें।

- background resume पर अनावश्यक splash न हो।

- implementation/testing अभी verify करना बाकी है।

Suggested copy:

- Come-In

- “Shop Local • Support Local”

- “Local Shops • Home Services & More”

Final use मौजूदा approved design और screen space के अनुसार तय करें।

---

## 6. Backup, GitHub और Project Continuity

- मौजूदा project और backup files की पहचान करें।

- GitHub repo/branch/commit status तभी बताएं जब verify किया हो।

- ZIP backup और repository backup अलग हैं।

- दूसरे Emergent/Replit/account में ले जाने से पहले project files, environment variables, secrets, database, assets और integrations की dependencies सूचीबद्ध करें।

- secrets को ZIP, public GitHub या prompt में न डालें।

- restore test के बिना backup को fully recoverable न कहें।

- credits खत्म हों तो नए बदलाव रोककर सुरक्षित स्थिति, किए गए काम और अगला कदम लिखें।

- development credits, hosting, APIs, payment fees और deployment costs अलग हो सकते हैं।

---

## 7. Ideas Not Approved for Main Roadmap

इनको अपने-आप मुख्य roadmap में न जोड़ें; पहले founder की अनुमति लें:

- multi-shop combined order और अलग delivery fees/times

- direct shop contact/call/WhatsApp

- “Find this for me” photo/text request

- elder-friendly UI और voice search

- cross-shop loyalty/rewards

- scheduled delivery/pickup

- shop business dashboard

- city/local market hub

- Verified Local Shop badge

Shop Call Assistance Task 11 का planned subtask है; operations validate करना बाकी है।

---

## 8. Business Model और Rough Monthly Cost Context

संभावित earning options—पहले economics और feasibility जाँचें:

- optional shop subscriptions

- clearly labelled sponsored promotions

- delivery fee/partnership

- Home Services commission

पहले एक locality में reliable service, repeat orders और fulfilment पर ध्यान दें।

पहले चर्चा में 500 active users, 1,000 orders/month, और shops/restaurants द्वारा अपनी delivery संभालने की assumption पर rough estimate:

- technical running costs: ₹2,000–₹7,000/month

- अगर ₹300 average order × 1,000 orders = ₹3,00,000 gateway से process हों और illustrative 2% fee लगे, तो ₹6,000 fee + 18% GST ₹1,080 = ₹7,080; उस assumption पर rough total ₹9,000–₹15,000/month।

- safe planning estimate के रूप में ₹15,000/month कहा गया था।

ये पुराने rough estimates हैं, guaranteed cost या provider quote नहीं। Actual hosting, OTP/SMS, API usage, GST, payment method/contract, delivery और traffic से cost बदलेगी। जरूरत हो तो current provider pricing verify करें। Shop/restaurant की own delivery होने पर भी operational agreement और responsibility स्पष्ट होनी चाहिए।

---

## 9. Test Catalog Files

पहले synthetic demo files बनाए गए थे:

- ComeIn_Test_Catalog_2000_Items.xlsx

- ComeIn_Test_Catalog_2000_Items.csv

- ComeIn_Price_Comparison_Test_15_Offers.csv

- ComeIn_Test_Catalog_README.txt

इनमें demo/synthetic data है, वास्तविक retailer prices नहीं। अगली बातचीत में files तभी उपलब्ध मानें जब वे attach हों या accessible Library में मिलें। पुराने download paths verify किए बिना न बनाएँ।

Importer/price comparison tests:

1. successful import और row count

2. stable product_id पर update, duplicates नहीं

3. stock/status update और out-of-stock behavior

4. same product के multi-shop offers में cheapest available offer पहले

5. duplicate IDs, blank names, negative prices, invalid stock और wrong columns validation

6. last-updated time, अगर supported हो

Test चलाए बिना test result का दावा न करें।

---

## 10. अगली बार काम कैसे शुरू करना है?

जब founder Come-In पर काम फिर शुरू करे:

1. current project location और available access पहचानें।

2. files/ZIP/repository उपलब्ध हों तो Task 1 का read-only audit करें।

3. screens, buttons, online/offline shops, restaurants, Home Services, carts, account, backend/API/database और current errors जाँचें।

4. concise report दें: verified working, broken, missing, duplicate और uncertain।

5. approval के बिना code changes न करें।

6. audit के बाद priority-based plan दें और approval लें।

7. छोटे changes करें, relevant tests चलाएँ, results और limitations बताएं।

8. credits/cost risks और external dependencies पहले समझाएँ।

9. missing context पर अनुमान न लगाएँ; जरूरत हो तो एक सीधा सवाल पूछें।

---

## 11. Special Trigger Phrase

जब मैं यह exact phrase लिखूँ:

**“टन टना टन टन टन तारा”**

तो इस prompt और उपलब्ध saved conversation context के आधार पर:

- सभी 22 main tasks की पूरी सूची दिखाएँ।

- हर task के approved subtasks और related requirements भी दिखाएँ।

- Restaurant Mode का automatic logo/theme switching, separate carts, Come-In Home button और unified brand identity शामिल करें।

- Home Services, Smart Notifications, Smart Price Comparison, security, backups और अन्य saved project requirements शामिल करें।

- status केवल evidence के आधार पर बताएं; अज्ञात status को unknown/pending कहें।

- implementation, test, backup या document update का दावा verify किए बिना न करें।

यह phrase roadmap/context सामने लाने का trigger है, automatic code modification या deployment की अनुमति नहीं।

---

## 12. Final Working Principle

**पहले समझो और audit करो → फिर plan बताओ → मेरी approval लो → छोटे बदलाव करो → test करो → परिणाम बताओ → backup और continuity सुरक्षित रखो।**

Come-In की existing functionality और data की सुरक्षा, स्पष्ट communication और verified results सबसे महत्वपूर्ण हैं।