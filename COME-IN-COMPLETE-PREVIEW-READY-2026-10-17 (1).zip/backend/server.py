# Come In — Backend (FastAPI + MongoDB)
#
# Single-file server for the Come In marketplace. Everything is namespaced
# under /api/*. Auth uses Bearer JWT in the Authorization header (Expo
# React Native Web stores it in SecureStore / AsyncStorage).
#
# Roles:
#   - customer    (default on register)
#   - shopkeeper  (customer that has registered a shop)
#   - admin       (seeded from env)
#
# Images are stored on disk at /app/backend/uploads and served from
# /api/uploads/<file>. This avoids any 3rd-party dependency for the
# first delivery; a Cloudinary adapter can slot in later.

from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import os
import re
import uuid
import logging
import secrets
import mimetypes
from datetime import datetime, timezone, timedelta
from typing import Annotated, List, Optional, Literal

import bcrypt
import jwt
import requests
from bson import ObjectId
from fastapi import (
    APIRouter,
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    Response,
    UploadFile,
    status,
)
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, BeforeValidator, EmailStr, Field, field_validator
from starlette.middleware.cors import CORSMiddleware
from restaurant_pricing import calculate_restaurant_totals

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("comein")

# ---------------------------------------------------------------------------
# Mongo + uploads
# ---------------------------------------------------------------------------

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]
client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

# Emergent object storage (shared bucket, authenticated via EMERGENT_LLM_KEY).
# Images persist across deploys instead of living on the app pod.
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY")
APP_NAME = "comein"
_storage_key: Optional[str] = None


def init_storage(force: bool = False) -> Optional[str]:
    global _storage_key
    if _storage_key and not force:
        return _storage_key
    if not EMERGENT_KEY:
        logger.warning("EMERGENT_LLM_KEY missing; uploads disabled")
        return None
    try:
        resp = requests.post(
            f"{STORAGE_URL}/init", json={"emergent_key": EMERGENT_KEY}, timeout=30
        )
        resp.raise_for_status()
        _storage_key = resp.json()["storage_key"]
        return _storage_key
    except Exception as e:
        logger.error("Object storage init failed: %s", e)
        return None


def put_object(path: str, data: bytes, content_type: str) -> dict:
    key = init_storage()
    if not key:
        raise HTTPException(status_code=503, detail="Object storage unavailable")
    resp = requests.put(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key, "Content-Type": content_type},
        data=data,
        timeout=120,
    )
    if resp.status_code == 404:
        # Stale key — mint a new one and retry once
        key = init_storage(force=True)
        if not key:
            raise HTTPException(status_code=503, detail="Object storage unavailable")
        resp = requests.put(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key, "Content-Type": content_type},
            data=data,
            timeout=120,
        )
    resp.raise_for_status()
    return resp.json()


def get_object(path: str) -> tuple[bytes, str]:
    key = init_storage()
    if not key:
        raise HTTPException(status_code=503, detail="Object storage unavailable")
    resp = requests.get(
        f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=60
    )
    if resp.status_code == 404:
        key = init_storage(force=True)
        if not key:
            raise HTTPException(status_code=503, detail="Object storage unavailable")
        resp = requests.get(
            f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=60
        )
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")

# ---------------------------------------------------------------------------
# Shared model helpers (BaseDocument pattern)
# ---------------------------------------------------------------------------

PyObjectId = Annotated[str, BeforeValidator(lambda v: str(v) if isinstance(v, ObjectId) else v)]


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def now_iso() -> str:
    return now_utc().isoformat()


class BaseDoc(BaseModel):
    id: Optional[PyObjectId] = Field(default=None, alias="_id")
    created_at: datetime = Field(default_factory=now_utc)
    updated_at: datetime = Field(default_factory=now_utc)

    model_config = {"populate_by_name": True, "arbitrary_types_allowed": True}


def doc_out(doc: dict) -> dict:
    """Serialize a Mongo document for JSON output: _id -> id (string)."""
    if not doc:
        return doc
    d = dict(doc)
    if "_id" in d:
        d["id"] = str(d.pop("_id"))
    # Never leak password hashes
    d.pop("password_hash", None)
    return d


# ---------------------------------------------------------------------------
# Password + JWT
# ---------------------------------------------------------------------------

BCRYPT_ROUNDS = 12
JWT_ALG = "HS256"
ACCESS_TTL_MIN = 60 * 24 * 7  # 7 days — mobile apps hold long-lived tokens


def hash_password(password: str) -> str:
    return bcrypt.hashpw(
        password.encode("utf-8"), bcrypt.gensalt(rounds=BCRYPT_ROUNDS)
    ).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def _jwt_secret() -> str:
    return os.environ["JWT_SECRET"]


def create_access_token(user_id: str, role: str, email: str) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "email": email,
        "type": "access",
        "exp": now_utc() + timedelta(minutes=ACCESS_TTL_MIN),
    }
    return jwt.encode(payload, _jwt_secret(), algorithm=JWT_ALG)


async def get_bearer_token(request: Request) -> Optional[str]:
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:].strip() or None
    return None


async def get_current_user_optional(request: Request) -> Optional[dict]:
    token = await get_bearer_token(request)
    if not token:
        return None
    try:
        payload = jwt.decode(token, _jwt_secret(), algorithms=[JWT_ALG])
        if payload.get("type") != "access":
            return None
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            return None
        return doc_out(user)
    except (jwt.PyJWTError, Exception):
        return None


async def get_current_user(request: Request) -> dict:
    user = await get_current_user_optional(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


def require_role(*roles: str):
    async def _dep(user: dict = Depends(get_current_user)) -> dict:
        if user.get("role") not in roles:
            raise HTTPException(status_code=403, detail="Forbidden")
        return user

    return _dep


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------


class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)
    phone: Optional[str] = Field(default=None, max_length=20)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class AuthOut(BaseModel):
    token: str
    user: dict


# Shops ----------------------------------------------------------------------


class ShopIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    tagline: str = Field(default="", max_length=160)
    description: str = Field(default="", max_length=1200)
    owner_name: str = Field(default="", max_length=120)
    phone: str = Field(min_length=5, max_length=20)
    alt_phone: Optional[str] = Field(default=None, max_length=20)
    whatsapp: Optional[str] = Field(default=None, max_length=20)
    category_ids: List[str] = Field(default_factory=list)
    area: str = Field(default="", max_length=160)
    address: str = Field(default="", max_length=400)
    city: str = Field(default="", max_length=80)
    state: str = Field(default="", max_length=80)
    pincode: str = Field(default="", max_length=12)
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    hours: str = Field(default="", max_length=120)
    holidays: List[str] = Field(default_factory=list)
    services: List[str] = Field(default_factory=list)
    delivery_available: bool = False
    pickup_available: bool = True
    delivery_radius_km: Optional[float] = None
    payment_methods: List[str] = Field(default_factory=lambda: ["cod"])
    public_upi: Optional[str] = Field(default=None, max_length=80)
    shop_type: Literal["online", "offline", "both"] = "offline"
    image_url: Optional[str] = None
    gallery: List[str] = Field(default_factory=list)
    business_registration: Optional[str] = Field(default=None, max_length=80)


# Products -------------------------------------------------------------------


class ProductIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    brand: str = Field(default="", max_length=80)
    unit: str = Field(default="", max_length=40)
    price: float = Field(ge=0)
    mrp: Optional[float] = Field(default=None, ge=0)
    stock: int = Field(default=0, ge=0)
    image_url: Optional[str] = None
    category_id: str = Field(default="", max_length=40)
    description: str = Field(default="", max_length=1200)
    available: bool = True

    @field_validator("mrp")
    @classmethod
    def mrp_gte_price(cls, v, info):
        if v is None:
            return v
        price = info.data.get("price", 0)
        if v < price:
            raise ValueError("MRP cannot be less than selling price")
        return v


# Orders ---------------------------------------------------------------------


class CartLine(BaseModel):
    product_id: str
    name: str
    unit: str = ""
    price: float = Field(ge=0)
    qty: int = Field(ge=1)
    image_url: Optional[str] = None
    shop_id: Optional[str] = None


class OrderIn(BaseModel):
    items: List[CartLine]
    delivery_address: str = Field(min_length=1, max_length=400)
    customer_name: str = Field(default="", max_length=120)
    customer_phone: str = Field(default="", max_length=20)
    delivery_fee: float = Field(default=0, ge=0)
    payment_method: Literal["cod", "online_stripe", "online_razorpay"] = "cod"
    notes: str = Field(default="", max_length=400)
    shop_id: Optional[str] = None  # for seller-scoped orders

    @field_validator("items")
    @classmethod
    def non_empty(cls, v):
        if not v:
            raise ValueError("Order has no items")
        return v


class OrderStatusUpdate(BaseModel):
    status: Literal[
        "pending", "accepted", "preparing", "ready", "out_for_delivery", "delivered", "cancelled"
    ]
    note: str = Field(default="", max_length=240)


# Requests -------------------------------------------------------------------


class RequestAnythingIn(BaseModel):
    description: str = Field(min_length=1, max_length=1200)
    pickup: str = Field(default="", max_length=240)
    drop: str = Field(min_length=1, max_length=240)
    size: str = Field(default="Small", max_length=24)
    quantity: int = Field(default=1, ge=1)
    budget: Optional[float] = Field(default=None, ge=0)
    category: str = Field(default="", max_length=80)
    reference_image_url: Optional[str] = None
    notes: str = Field(default="", max_length=400)
    customer_name: str = Field(default="", max_length=120)
    customer_phone: str = Field(default="", max_length=20)


class AgentAssistIn(BaseModel):
    shop_id: Optional[str] = None
    reason: str = Field(min_length=1, max_length=600)
    preferred_time: str = Field(default="", max_length=80)
    instructions: str = Field(default="", max_length=600)
    customer_name: str = Field(default="", max_length=120)
    customer_phone: str = Field(default="", max_length=20)


# ---------------------------------------------------------------------------
# App + router
# ---------------------------------------------------------------------------

app = FastAPI(title="Come In API")
api = APIRouter(prefix="/api")


# Health ---------------------------------------------------------------------


@api.get("/")
async def root():
    return {"service": "come-in", "status": "ok", "time": now_iso()}


# Legacy status endpoints retained for backward compatibility -----------------


class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=now_utc)


class StatusCheckCreate(BaseModel):
    client_name: str


@api.post("/status", response_model=StatusCheck)
async def create_status_check(payload: StatusCheckCreate):
    obj = StatusCheck(**payload.model_dump())
    await db.status_checks.insert_one(obj.model_dump())
    return obj


@api.get("/status", response_model=List[StatusCheck])
async def list_status_checks():
    rows = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**r) for r in rows]


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


@api.post("/auth/register", response_model=AuthOut)
async def register(body: RegisterIn):
    email = body.email.lower().strip()
    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user_doc = {
        "name": body.name.strip(),
        "email": email,
        "phone": (body.phone or "").strip(),
        "password_hash": hash_password(body.password),
        "role": "customer",
        "created_at": now_utc(),
        "updated_at": now_utc(),
    }
    res = await db.users.insert_one(user_doc)
    user_doc["_id"] = res.inserted_id
    token = create_access_token(str(res.inserted_id), "customer", email)
    return {"token": token, "user": doc_out(user_doc)}


@api.post("/auth/login", response_model=AuthOut)
async def login(body: LoginIn):
    email = body.email.lower().strip()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token(str(user["_id"]), user.get("role", "customer"), email)
    return {"token": token, "user": doc_out(user)}


@api.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return user


class UpdateProfileIn(BaseModel):
    name: Optional[str] = Field(default=None, max_length=120)
    phone: Optional[str] = Field(default=None, max_length=20)


@api.patch("/auth/me")
async def update_me(body: UpdateProfileIn, user: dict = Depends(get_current_user)):
    patch = {k: v for k, v in body.model_dump(exclude_none=True).items()}
    if not patch:
        return user
    patch["updated_at"] = now_utc()
    await db.users.update_one({"_id": ObjectId(user["id"])}, {"$set": patch})
    fresh = await db.users.find_one({"_id": ObjectId(user["id"])})
    return doc_out(fresh)


# Password reset (email delivery is enabled only when SMTP settings are supplied)
class ForgotPasswordIn(BaseModel):
    email: EmailStr

class ResetPasswordIn(BaseModel):
    token: str = Field(min_length=32, max_length=256)
    new_password: str = Field(min_length=8, max_length=128)

async def _send_password_reset_email(email: str, token: str) -> bool:
    host=os.environ.get("SMTP_HOST"); sender=os.environ.get("SMTP_FROM"); base=os.environ.get("PASSWORD_RESET_URL")
    if not host or not sender or not base:
        return False
    import smtplib
    from email.message import EmailMessage
    msg=EmailMessage(); msg["Subject"]="Reset your Come-In password"; msg["From"]=sender; msg["To"]=email
    msg.set_content(f"Use this one-time link to reset your Come-In password: {base.rstrip('/')}?token={token}\nIf you did not request this, ignore this email. The link expires in 30 minutes.")
    port=int(os.environ.get("SMTP_PORT","587")); user=os.environ.get("SMTP_USER"); password=os.environ.get("SMTP_PASSWORD")
    try:
        with smtplib.SMTP(host,port,timeout=10) as smtp:
            smtp.starttls()
            if user and password: smtp.login(user,password)
            smtp.send_message(msg)
        return True
    except Exception as exc:
        logger.error("Password reset email could not be sent: %s", type(exc).__name__)
        return False

@api.post("/auth/password/forgot")
async def forgot_password(body: ForgotPasswordIn):
    # Always return the same public response to prevent account enumeration.
    email=body.email.lower().strip(); user=await db.users.find_one({"email":email})
    if user:
        token=secrets.token_urlsafe(36); digest=hashlib.sha256(token.encode()).hexdigest()
        await db.password_resets.delete_many({"user_id":str(user["_id"])})
        await db.password_resets.insert_one({"user_id":str(user["_id"]),"token_hash":digest,"expires_at":now_utc()+timedelta(minutes=30),"used":False,"created_at":now_utc()})
        delivered=await _send_password_reset_email(email,token)
        if not delivered:
            # Invalidate a token that was not delivered. Never return reset tokens to the API caller.
            await db.password_resets.delete_many({"user_id":str(user["_id"]),"token_hash":digest})
            logger.warning("Password reset requested but SMTP/PASSWORD_RESET_URL is not configured")
    return {"message":"If that email is registered and reset email is configured, instructions will be sent."}

@api.post("/auth/password/reset")
async def reset_password(body: ResetPasswordIn):
    digest=hashlib.sha256(body.token.encode()).hexdigest(); record=await db.password_resets.find_one({"token_hash":digest,"used":False,"expires_at":{"$gt":now_utc()}})
    if not record: raise HTTPException(status_code=400,detail="Reset link is invalid or expired")
    user_id=_object_id_or_404(record["user_id"],"User")
    await db.users.update_one({"_id":user_id},{"$set":{"password_hash":hash_password(body.new_password),"updated_at":now_utc()}})
    await db.password_resets.update_one({"_id":record["_id"]},{"$set":{"used":True,"used_at":now_utc()}})
    return {"reset":True,"message":"Password updated. Please sign in again."}

# ---------------------------------------------------------------------------
# Uploads (images)
# ---------------------------------------------------------------------------


ALLOWED_IMAGE = {"image/jpeg", "image/png", "image/webp", "image/gif"}
MAX_UPLOAD_BYTES = 5 * 1024 * 1024  # 5 MB


@api.post("/uploads/image")
async def upload_image(
    file: UploadFile = File(...),
    user: dict = Depends(get_current_user),
):
    content_type = file.content_type or mimetypes.guess_type(file.filename or "")[0] or ""
    if content_type not in ALLOWED_IMAGE:
        raise HTTPException(status_code=400, detail="Only JPEG/PNG/WEBP/GIF images are allowed")
    data = await file.read()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=400, detail="Image too large (max 5 MB)")
    ext = (mimetypes.guess_extension(content_type) or ".jpg").lstrip(".")
    if ext == "jpe":
        ext = "jpg"
    fname = f"{uuid.uuid4().hex}.{ext}"
    path = f"{APP_NAME}/uploads/{user['id']}/{fname}"
    result = put_object(path, data, content_type)
    # Keep a soft-delete friendly reference in Mongo
    await db.files.insert_one(
        {
            "storage_path": result["path"],
            "owner_id": user["id"],
            "content_type": content_type,
            "size": result.get("size", len(data)),
            "is_deleted": False,
            "created_at": now_utc(),
        }
    )
    # Frontend-facing URL always goes through the backend so we can serve
    # the right bytes + Content-Type.
    return {"url": f"/api/uploads/{result['path']}", "storage_path": result["path"]}


@api.get("/uploads/{storage_path:path}")
async def serve_upload(storage_path: str):
    if ".." in storage_path:
        raise HTTPException(status_code=400, detail="Invalid path")
    record = await db.files.find_one({"storage_path": storage_path, "is_deleted": False})
    if not record:
        raise HTTPException(status_code=404, detail="File not found")
    data, ct = get_object(storage_path)
    return Response(content=data, media_type=record.get("content_type") or ct)


# ---------------------------------------------------------------------------
# Shops (shopkeeper + public)
# ---------------------------------------------------------------------------


async def _get_shop_or_404(shop_id: str) -> dict:
    try:
        oid = ObjectId(shop_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Shop not found")
    shop = await db.shops.find_one({"_id": oid})
    if not shop:
        raise HTTPException(status_code=404, detail="Shop not found")
    return shop


def _assert_shop_owner(shop: dict, user: dict):
    if user.get("role") == "admin":
        return
    if shop.get("owner_id") != user["id"]:
        raise HTTPException(status_code=403, detail="You can only modify your own shop")


@api.post("/shops")
async def create_shop(body: ShopIn, user: dict = Depends(get_current_user)):
    """A customer creates a shop and becomes a shopkeeper."""
    # Only one active shop per owner for the MVP
    existing = await db.shops.find_one({"owner_id": user["id"]})
    if existing:
        raise HTTPException(status_code=400, detail="You already have a shop registered")
    doc = body.model_dump()
    doc.update(
        {
            "owner_id": user["id"],
            "status": "pending",  # pending -> approved -> suspended
            "online": False,  # seller toggles after approval
            "created_at": now_utc(),
            "updated_at": now_utc(),
        }
    )
    res = await db.shops.insert_one(doc)
    doc["_id"] = res.inserted_id
    # Promote the user to shopkeeper
    if user.get("role") == "customer":
        await db.users.update_one(
            {"_id": ObjectId(user["id"])}, {"$set": {"role": "shopkeeper", "updated_at": now_utc()}}
        )
    return doc_out(doc)


@api.get("/shops/mine")
async def my_shop(user: dict = Depends(get_current_user)):
    shop = await db.shops.find_one({"owner_id": user["id"]})
    if not shop:
        return None
    return doc_out(shop)


@api.patch("/shops/{shop_id}")
async def update_shop(shop_id: str, body: ShopIn, user: dict = Depends(get_current_user)):
    shop = await _get_shop_or_404(shop_id)
    _assert_shop_owner(shop, user)
    patch = body.model_dump()
    patch["updated_at"] = now_utc()
    await db.shops.update_one({"_id": shop["_id"]}, {"$set": patch})
    fresh = await db.shops.find_one({"_id": shop["_id"]})
    return doc_out(fresh)


class ShopAvailabilityIn(BaseModel):
    online: bool


@api.patch("/shops/{shop_id}/availability")
async def set_shop_availability(
    shop_id: str, body: ShopAvailabilityIn, user: dict = Depends(get_current_user)
):
    shop = await _get_shop_or_404(shop_id)
    _assert_shop_owner(shop, user)
    if shop.get("status") != "approved":
        raise HTTPException(status_code=400, detail="Shop must be approved before going online")
    await db.shops.update_one(
        {"_id": shop["_id"]}, {"$set": {"online": bool(body.online), "updated_at": now_utc()}}
    )
    fresh = await db.shops.find_one({"_id": shop["_id"]})
    return doc_out(fresh)


@api.get("/shops")
async def list_shops(
    type: Optional[str] = None,
    online: Optional[str] = None,
    q: Optional[str] = None,
):
    """Public list of approved shops."""
    filt: dict = {"status": "approved"}
    if type in ("online", "offline", "both"):
        filt["shop_type"] = type
    if online == "true":
        filt["online"] = True
    if online == "false":
        filt["online"] = False
    cursor = db.shops.find(filt).sort("created_at", -1)
    rows = [doc_out(r) async for r in cursor]
    if q:
        ql = q.lower()
        rows = [
            r
            for r in rows
            if ql in r.get("name", "").lower()
            or ql in r.get("area", "").lower()
            or ql in r.get("address", "").lower()
            or ql in r.get("tagline", "").lower()
        ]
    return rows


@api.get("/shops/{shop_id}")
async def get_shop(shop_id: str):
    shop = await _get_shop_or_404(shop_id)
    if shop.get("status") != "approved":
        # Owners/admins can still fetch via /shops/mine; this is the public route.
        raise HTTPException(status_code=404, detail="Shop not available")
    return doc_out(shop)


# ---------------------------------------------------------------------------
# Products (shop-scoped)
# ---------------------------------------------------------------------------


@api.post("/shops/{shop_id}/products")
async def create_product(
    shop_id: str, body: ProductIn, user: dict = Depends(get_current_user)
):
    shop = await _get_shop_or_404(shop_id)
    _assert_shop_owner(shop, user)
    doc = body.model_dump()
    doc.update(
        {
            "shop_id": shop_id,
            "owner_id": user["id"],
            "created_at": now_utc(),
            "updated_at": now_utc(),
        }
    )
    res = await db.products.insert_one(doc)
    doc["_id"] = res.inserted_id
    return doc_out(doc)


@api.get("/shops/{shop_id}/products")
async def list_shop_products(shop_id: str):
    cursor = db.products.find({"shop_id": shop_id}).sort("created_at", -1)
    return [doc_out(r) async for r in cursor]


@api.patch("/products/{product_id}")
async def update_product(
    product_id: str, body: ProductIn, user: dict = Depends(get_current_user)
):
    try:
        pid = ObjectId(product_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Product not found")
    product = await db.products.find_one({"_id": pid})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    if user.get("role") != "admin" and product.get("owner_id") != user["id"]:
        raise HTTPException(status_code=403, detail="Not your product")
    patch = body.model_dump()
    patch["updated_at"] = now_utc()
    await db.products.update_one({"_id": pid}, {"$set": patch})
    fresh = await db.products.find_one({"_id": pid})
    return doc_out(fresh)


@api.delete("/products/{product_id}")
async def delete_product(product_id: str, user: dict = Depends(get_current_user)):
    try:
        pid = ObjectId(product_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Product not found")
    product = await db.products.find_one({"_id": pid})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    if user.get("role") != "admin" and product.get("owner_id") != user["id"]:
        raise HTTPException(status_code=403, detail="Not your product")
    await db.products.delete_one({"_id": pid})
    return {"deleted": True}


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------


def _order_total(items: List[CartLine], delivery_fee: float) -> float:
    return round(sum(line.price * line.qty for line in items) + delivery_fee, 2)


@api.post("/orders")
async def create_order(body: OrderIn, request: Request):
    # Public endpoint (guests can place COD orders); if logged-in we tag them.
    user = await get_current_user_optional(request)
    # Compute server-side total; never trust client numbers for totals.
    total = _order_total(body.items, body.delivery_fee)
    subtotal = round(sum(line.price * line.qty for line in body.items), 2)

    # Decrement stock for products the seller actually owns.
    for line in body.items:
        try:
            pid = ObjectId(line.product_id) if line.product_id else None
        except Exception:
            pid = None
        if pid:
            prod = await db.products.find_one({"_id": pid})
            if prod and prod.get("stock", 0) >= line.qty:
                await db.products.update_one(
                    {"_id": pid}, {"$inc": {"stock": -line.qty}, "$set": {"updated_at": now_utc()}}
                )

    short_ref = f"CI-{secrets.token_hex(3).upper()}"
    doc = {
        "ref": short_ref,
        "customer_id": user["id"] if user else None,
        "customer_name": body.customer_name,
        "customer_phone": body.customer_phone,
        "delivery_address": body.delivery_address,
        "items": [line.model_dump() for line in body.items],
        "subtotal": subtotal,
        "delivery_fee": body.delivery_fee,
        "total": total,
        "payment_method": body.payment_method,
        "payment_status": "unpaid" if body.payment_method != "cod" else "cod_pending",
        "status": "pending",
        "status_history": [{"status": "pending", "at": now_utc(), "note": "Order placed"}],
        "notes": body.notes,
        "shop_id": body.shop_id,
        "created_at": now_utc(),
        "updated_at": now_utc(),
    }
    if body.payment_method in ("online_stripe", "online_razorpay"):
        # Online payments are scaffolded. The frontend will not expose this path
        # until credentials are configured. We return the created order with
        # payment_status=unpaid so an admin can wire the gateway later.
        doc["payment_status"] = "awaiting_gateway"
    res = await db.orders.insert_one(doc)
    doc["_id"] = res.inserted_id
    return doc_out(doc)


@api.get("/orders/mine")
async def my_orders(user: dict = Depends(get_current_user)):
    cursor = db.orders.find({"customer_id": user["id"]}).sort("created_at", -1)
    return [doc_out(r) async for r in cursor]


@api.get("/shops/{shop_id}/orders")
async def shop_orders(shop_id: str, user: dict = Depends(get_current_user)):
    shop = await _get_shop_or_404(shop_id)
    _assert_shop_owner(shop, user)
    cursor = db.orders.find({"shop_id": shop_id}).sort("created_at", -1)
    return [doc_out(r) async for r in cursor]


@api.patch("/orders/{order_id}/status")
async def update_order_status(
    order_id: str, body: OrderStatusUpdate, user: dict = Depends(get_current_user)
):
    try:
        oid = ObjectId(order_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Order not found")
    order = await db.orders.find_one({"_id": oid})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    # Only shop owner or admin may change status.
    if user.get("role") != "admin":
        if not order.get("shop_id"):
            raise HTTPException(status_code=403, detail="Not your order")
        shop = await db.shops.find_one({"_id": ObjectId(order["shop_id"])})
        if not shop or shop.get("owner_id") != user["id"]:
            raise HTTPException(status_code=403, detail="Not your order")
    history_entry = {"status": body.status, "at": now_utc(), "note": body.note}
    await db.orders.update_one(
        {"_id": oid},
        {
            "$set": {"status": body.status, "updated_at": now_utc()},
            "$push": {"status_history": history_entry},
        },
    )
    fresh = await db.orders.find_one({"_id": oid})
    return doc_out(fresh)


# ---------------------------------------------------------------------------
# Requests: Request-Anything + Agent assistance
# ---------------------------------------------------------------------------


@api.post("/requests/anything")
async def submit_request_anything(body: RequestAnythingIn, request: Request):
    user = await get_current_user_optional(request)
    short_ref = f"RQ-{secrets.token_hex(3).upper()}"
    doc = body.model_dump()
    doc.update(
        {
            "ref": short_ref,
            "customer_id": user["id"] if user else None,
            "status": "pending",
            "status_history": [{"status": "pending", "at": now_utc(), "note": "Request received"}],
            "created_at": now_utc(),
            "updated_at": now_utc(),
        }
    )
    res = await db.request_anything.insert_one(doc)
    doc["_id"] = res.inserted_id
    return doc_out(doc)


@api.get("/requests/anything/mine")
async def my_requests_anything(user: dict = Depends(get_current_user)):
    cursor = db.request_anything.find({"customer_id": user["id"]}).sort("created_at", -1)
    return [doc_out(r) async for r in cursor]


@api.post("/requests/assist")
async def submit_agent_assist(body: AgentAssistIn, request: Request):
    user = await get_current_user_optional(request)
    short_ref = f"AG-{secrets.token_hex(3).upper()}"
    doc = body.model_dump()
    doc.update(
        {
            "ref": short_ref,
            "customer_id": user["id"] if user else None,
            "status": "pending",
            "status_history": [{"status": "pending", "at": now_utc(), "note": "Awaiting agent"}],
            "created_at": now_utc(),
            "updated_at": now_utc(),
        }
    )
    res = await db.agent_assist.insert_one(doc)
    doc["_id"] = res.inserted_id
    return doc_out(doc)


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------


@api.get("/admin/shops")
async def admin_shops(_: dict = Depends(require_role("admin"))):
    cursor = db.shops.find().sort("created_at", -1)
    return [doc_out(r) async for r in cursor]


class ShopApprovalIn(BaseModel):
    status: Literal["approved", "suspended", "pending"]


@api.patch("/admin/shops/{shop_id}/status")
async def admin_set_shop_status(
    shop_id: str, body: ShopApprovalIn, _: dict = Depends(require_role("admin"))
):
    shop = await _get_shop_or_404(shop_id)
    await db.shops.update_one(
        {"_id": shop["_id"]},
        {"$set": {"status": body.status, "updated_at": now_utc()}},
    )
    fresh = await db.shops.find_one({"_id": shop["_id"]})
    return doc_out(fresh)


@api.get("/admin/orders")
async def admin_orders(_: dict = Depends(require_role("admin"))):
    cursor = db.orders.find().sort("created_at", -1).limit(500)
    return [doc_out(r) async for r in cursor]


@api.get("/admin/requests/anything")
async def admin_requests_anything(_: dict = Depends(require_role("admin"))):
    cursor = db.request_anything.find().sort("created_at", -1).limit(500)
    return [doc_out(r) async for r in cursor]


@api.get("/admin/requests/assist")
async def admin_agent_assist(_: dict = Depends(require_role("admin"))):
    cursor = db.agent_assist.find().sort("created_at", -1).limit(500)
    return [doc_out(r) async for r in cursor]


class RequestStatusIn(BaseModel):
    status: Literal["pending", "assigned", "in_progress", "completed", "cancelled"]
    note: str = Field(default="", max_length=240)


@api.patch("/admin/requests/anything/{req_id}/status")
async def admin_update_request(
    req_id: str, body: RequestStatusIn, _: dict = Depends(require_role("admin"))
):
    try:
        oid = ObjectId(req_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Request not found")
    item = await db.request_anything.find_one({"_id": oid})
    if not item:
        raise HTTPException(status_code=404, detail="Request not found")
    await db.request_anything.update_one(
        {"_id": oid},
        {
            "$set": {"status": body.status, "updated_at": now_utc()},
            "$push": {"status_history": {"status": body.status, "at": now_utc(), "note": body.note}},
        },
    )
    fresh = await db.request_anything.find_one({"_id": oid})
    return doc_out(fresh)


@api.patch("/admin/requests/assist/{req_id}/status")
async def admin_update_assist(
    req_id: str, body: RequestStatusIn, _: dict = Depends(require_role("admin"))
):
    try:
        oid = ObjectId(req_id)
    except Exception:
        raise HTTPException(status_code=404, detail="Request not found")
    item = await db.agent_assist.find_one({"_id": oid})
    if not item:
        raise HTTPException(status_code=404, detail="Request not found")
    await db.agent_assist.update_one(
        {"_id": oid},
        {
            "$set": {"status": body.status, "updated_at": now_utc()},
            "$push": {"status_history": {"status": body.status, "at": now_utc(), "note": body.note}},
        },
    )
    fresh = await db.agent_assist.find_one({"_id": oid})
    return doc_out(fresh)


# ---------------------------------------------------------------------------
# Restaurant Mode (approved subtask of roadmap Tasks 2, 3, 4, 6, 7, 10, 14, 16, 17, 18)
# ---------------------------------------------------------------------------

import hashlib
import hmac
import json

class AddressIn(BaseModel):
    label: str = Field(default="Home", min_length=1, max_length=40)
    recipient_name: str = Field(min_length=1, max_length=120)
    phone: str = Field(min_length=5, max_length=20)
    address_line: str = Field(min_length=5, max_length=400)
    city: str = Field(min_length=1, max_length=80)
    state: str = Field(min_length=1, max_length=80)
    pincode: str = Field(min_length=4, max_length=12)
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    is_default: bool = False

class RestaurantIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=1600)
    cuisines: List[str] = Field(default_factory=list, max_length=20)
    phone: str = Field(min_length=5, max_length=20)
    address: str = Field(min_length=5, max_length=400)
    city: str = Field(min_length=1, max_length=80)
    image_url: Optional[str] = None
    delivery_available: bool = True
    pickup_available: bool = True
    payment_methods: List[Literal["cod", "pickup", "razorpay"]] = Field(default_factory=lambda: ["cod", "pickup"], max_length=3)
    delivery_fee: float = Field(default=0, ge=0, le=10000)
    tax_rate: float = Field(default=5, ge=0, le=30)
    min_order: float = Field(default=0, ge=0)
    estimated_minutes: int = Field(default=35, ge=5, le=240)

class MenuItemIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=1200)
    category: str = Field(default="Main", max_length=80)
    price: float = Field(ge=0, le=100000)
    image_url: Optional[str] = None
    available: bool = True
    vegetarian: Optional[bool] = None
    variants: List[dict] = Field(default_factory=list, max_length=30)
    add_ons: List[dict] = Field(default_factory=list, max_length=50)

class RestaurantOrderLineIn(BaseModel):
    menu_item_id: str
    quantity: int = Field(ge=1, le=99)
    variant_id: Optional[str] = None
    add_on_ids: List[str] = Field(default_factory=list, max_length=50)
    instructions: str = Field(default="", max_length=300)

class RestaurantOrderIn(BaseModel):
    restaurant_id: str
    items: List[RestaurantOrderLineIn] = Field(min_length=1, max_length=100)
    address_id: Optional[str] = None
    delivery_address: Optional[str] = Field(default=None, max_length=700)
    contact_name: str = Field(min_length=1, max_length=120)
    contact_phone: str = Field(min_length=5, max_length=20)
    fulfillment: Literal["delivery", "pickup"] = "delivery"
    payment_method: Literal["cod", "pickup", "razorpay"] = "cod"
    notes: str = Field(default="", max_length=600)
    idempotency_key: str = Field(min_length=8, max_length=100)

class RestaurantStatusIn(BaseModel):
    status: Literal["accepted", "rejected", "preparing", "ready", "picked_up", "out_for_delivery", "delivered", "cancelled"]
    note: str = Field(default="", max_length=300)

class PaymentVerifyIn(BaseModel):
    order_id: str
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str

class RestaurantReviewIn(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: str = Field(default="", max_length=1000)


def _object_id_or_404(value: str, what: str):
    try:
        return ObjectId(value)
    except Exception:
        raise HTTPException(status_code=404, detail=f"{what} not found")

async def _restaurant_or_404(restaurant_id: str) -> dict:
    item = await db.restaurants.find_one({"_id": _object_id_or_404(restaurant_id, "Restaurant")})
    if not item:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    return item

def _restaurant_owner(restaurant: dict, user: dict):
    if user.get("role") != "admin" and restaurant.get("owner_id") != user.get("id"):
        raise HTTPException(status_code=403, detail="You cannot manage this restaurant")

def _restaurant_public(doc: dict) -> dict:
    out = doc_out(doc)
    out.pop("owner_id", None)
    return out

@api.get("/restaurants")
async def list_restaurants(q: Optional[str] = None, cuisine: Optional[str] = None, min_rating: Optional[float] = Query(default=None, ge=0, le=5), max_delivery_fee: Optional[float] = Query(default=None, ge=0), available: bool = True, city: Optional[str] = None):
    query: dict = {"status": "approved"}
    if available:
        query["available"] = True
    if city:
        query["city"] = {"$regex": re.escape(city.strip()), "$options": "i"}
    rows = [doc_out(x) async for x in db.restaurants.find(query).sort("created_at", -1).limit(500)]
    ql = (q or "").strip().lower()
    cl = (cuisine or "").strip().lower()
    menu_restaurant_ids=set()
    if ql:
        async for menu_item in db.restaurant_menu.find({"$or":[{"name":{"$regex":re.escape(ql),"$options":"i"}},{"description":{"$regex":re.escape(ql),"$options":"i"}},{"category":{"$regex":re.escape(ql),"$options":"i"}}]},{"restaurant_id":1}):
            menu_restaurant_ids.add(menu_item.get("restaurant_id"))
    rows = [r for r in rows if (not ql or ql in r.get("name", "").lower() or ql in r.get("description", "").lower() or any(ql in c.lower() for c in r.get("cuisines", [])) or r.get("id") in menu_restaurant_ids) and (not cl or any(cl == c.lower() for c in r.get("cuisines", []))) and (min_rating is None or float(r.get("rating", 0)) >= min_rating) and (max_delivery_fee is None or float(r.get("delivery_fee", 0)) <= max_delivery_fee)]
    return [_restaurant_public(r) for r in rows]

@api.get("/restaurants/mine")
async def my_restaurants(user: dict = Depends(get_current_user)):
    return [doc_out(x) async for x in db.restaurants.find({"owner_id": user["id"]}).sort("created_at", -1)]

@api.post("/restaurants")
async def create_restaurant(body: RestaurantIn, user: dict = Depends(get_current_user)):
    doc = body.model_dump()
    doc.update({"owner_id": user["id"], "status": "pending", "available": False, "created_at": now_utc(), "updated_at": now_utc(), "rating": 0, "review_count": 0})
    result = await db.restaurants.insert_one(doc)
    doc["_id"] = result.inserted_id
    return doc_out(doc)

@api.get("/restaurants/{restaurant_id}")
async def restaurant_detail(restaurant_id: str):
    restaurant = await _restaurant_or_404(restaurant_id)
    if restaurant.get("status") != "approved" or not restaurant.get("available", False):
        raise HTTPException(status_code=404, detail="Restaurant is not currently available")
    return _restaurant_public(restaurant)

@api.patch("/restaurants/{restaurant_id}")
async def update_restaurant(restaurant_id: str, body: RestaurantIn, user: dict = Depends(get_current_user)):
    restaurant = await _restaurant_or_404(restaurant_id)
    _restaurant_owner(restaurant, user)
    patch = body.model_dump()
    patch["updated_at"] = now_utc()
    # Editing material business information returns an approved listing to pending review.
    patch["status"] = "pending"
    patch["available"] = False
    await db.restaurants.update_one({"_id": restaurant["_id"]}, {"$set": patch})
    return doc_out(await _restaurant_or_404(restaurant_id))

@api.patch("/restaurants/{restaurant_id}/availability")
async def restaurant_availability(restaurant_id: str, body: dict, user: dict = Depends(get_current_user)):
    restaurant = await _restaurant_or_404(restaurant_id)
    _restaurant_owner(restaurant, user)
    online = body.get("available")
    if not isinstance(online, bool):
        raise HTTPException(status_code=422, detail="available must be a boolean")
    if online and restaurant.get("status") != "approved":
        raise HTTPException(status_code=400, detail="Restaurant must be approved before accepting orders")
    await db.restaurants.update_one({"_id": restaurant["_id"]}, {"$set": {"available": online, "updated_at": now_utc()}})
    return doc_out(await _restaurant_or_404(restaurant_id))

@api.get("/restaurants/{restaurant_id}/menu")
async def restaurant_menu(restaurant_id: str, q: Optional[str] = None, category: Optional[str] = None):
    restaurant = await _restaurant_or_404(restaurant_id)
    if restaurant.get("status") != "approved":
        raise HTTPException(status_code=404, detail="Restaurant not found")
    filt = {"restaurant_id": restaurant_id}
    if category:
        filt["category"] = {"$regex": re.escape(category.strip()), "$options": "i"}
    if q:
        filt["$or"] = [{"name": {"$regex": re.escape(q.strip()), "$options": "i"}}, {"description": {"$regex": re.escape(q.strip()), "$options": "i"}}]
    return [doc_out(x) async for x in db.restaurant_menu.find(filt).sort("category", 1).limit(1000)]

@api.post("/restaurants/{restaurant_id}/menu")
async def create_menu_item(restaurant_id: str, body: MenuItemIn, user: dict = Depends(get_current_user)):
    restaurant = await _restaurant_or_404(restaurant_id)
    _restaurant_owner(restaurant, user)
    doc = body.model_dump()
    doc.update({"restaurant_id": restaurant_id, "owner_id": user["id"], "created_at": now_utc(), "updated_at": now_utc()})
    result = await db.restaurant_menu.insert_one(doc)
    doc["_id"] = result.inserted_id
    return doc_out(doc)

@api.patch("/restaurants/{restaurant_id}/menu/{item_id}")
async def update_menu_item(restaurant_id: str, item_id: str, body: MenuItemIn, user: dict = Depends(get_current_user)):
    restaurant = await _restaurant_or_404(restaurant_id)
    _restaurant_owner(restaurant, user)
    item = await db.restaurant_menu.find_one({"_id": _object_id_or_404(item_id, "Menu item"), "restaurant_id": restaurant_id})
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")
    patch = body.model_dump()
    patch["updated_at"] = now_utc()
    await db.restaurant_menu.update_one({"_id": item["_id"]}, {"$set": patch})
    return doc_out(await db.restaurant_menu.find_one({"_id": item["_id"]}))

@api.delete("/restaurants/{restaurant_id}/menu/{item_id}")
async def delete_menu_item(restaurant_id: str, item_id: str, user: dict = Depends(get_current_user)):
    restaurant = await _restaurant_or_404(restaurant_id)
    _restaurant_owner(restaurant, user)
    result = await db.restaurant_menu.delete_one({"_id": _object_id_or_404(item_id, "Menu item"), "restaurant_id": restaurant_id})
    if not result.deleted_count:
        raise HTTPException(status_code=404, detail="Menu item not found")
    return {"deleted": True}

@api.get("/addresses")
async def list_addresses(user: dict = Depends(get_current_user)):
    return [doc_out(x) async for x in db.addresses.find({"user_id": user["id"]}).sort("is_default", -1)]

@api.post("/addresses")
async def create_address(body: AddressIn, user: dict = Depends(get_current_user)):
    doc = body.model_dump()
    if doc.get("is_default"):
        await db.addresses.update_many({"user_id": user["id"]}, {"$set": {"is_default": False}})
    doc.update({"user_id": user["id"], "created_at": now_utc(), "updated_at": now_utc()})
    result = await db.addresses.insert_one(doc)
    doc["_id"] = result.inserted_id
    return doc_out(doc)

@api.patch("/addresses/{address_id}")
async def update_address(address_id: str, body: AddressIn, user: dict = Depends(get_current_user)):
    oid=_object_id_or_404(address_id,"Address")
    existing=await db.addresses.find_one({"_id":oid,"user_id":user["id"]})
    if not existing: raise HTTPException(status_code=404,detail="Address not found")
    patch=body.model_dump()
    if patch.get("is_default"):
        await db.addresses.update_many({"user_id":user["id"]},{"$set":{"is_default":False}})
    patch["updated_at"]=now_utc()
    await db.addresses.update_one({"_id":oid},{"$set":patch})
    return doc_out(await db.addresses.find_one({"_id":oid}))

@api.delete("/addresses/{address_id}")
async def delete_address(address_id: str, user: dict = Depends(get_current_user)):
    result = await db.addresses.delete_one({"_id": _object_id_or_404(address_id, "Address"), "user_id": user["id"]})
    if not result.deleted_count:
        raise HTTPException(status_code=404, detail="Address not found")
    return {"deleted": True}

class RestaurantCartIn(BaseModel):
    restaurant_id: str
    items: List[RestaurantOrderLineIn] = Field(default_factory=list, max_length=100)

@api.get("/restaurant/cart")
async def get_restaurant_cart(user: dict = Depends(get_current_user)):
    cart=await db.restaurant_carts.find_one({"user_id":user["id"]})
    if not cart: return {"restaurant_id":None,"items":[]}
    restaurant=await db.restaurants.find_one({"_id":_object_id_or_404(cart["restaurant_id"],"Restaurant")}) if cart.get("restaurant_id") else None
    output=[]
    for line in cart.get("items",[]):
        try: item=await db.restaurant_menu.find_one({"_id":ObjectId(line["menu_item_id"]),"restaurant_id":cart["restaurant_id"]})
        except Exception: item=None
        if item and item.get("available",True):
            unit_price=float(item["price"])
            variant=next((v for v in item.get("variants",[]) if isinstance(v,dict) and str(v.get("id"))==str(line.get("variant_id"))),None) if line.get("variant_id") else None
            if variant: unit_price=float(variant.get("price",unit_price))
            addons={str(a.get("id")):a for a in item.get("add_ons",[]) if isinstance(a,dict) and a.get("id")}
            for addon_id in line.get("add_on_ids",[]):
                if addon_id in addons: unit_price += float(addons[addon_id].get("price",0))
            output.append({**line,"name":item["name"],"price":round(unit_price,2),"image_url":item.get("image_url"),"description":item.get("description","")})
    return {"restaurant_id":cart.get("restaurant_id"),"restaurant_name":restaurant.get("name") if restaurant else None,"delivery_fee":float(restaurant.get("delivery_fee",0)) if restaurant else 0,"tax_rate":float(restaurant.get("tax_rate",5)) if restaurant else 5,"items":output,"updated_at":cart.get("updated_at")}

@api.put("/restaurant/cart")
async def save_restaurant_cart(body: RestaurantCartIn, user: dict = Depends(get_current_user)):
    restaurant=await _restaurant_or_404(body.restaurant_id)
    if restaurant.get("status")!="approved" or not restaurant.get("available",False): raise HTTPException(status_code=409,detail="Restaurant is not accepting orders")
    if len(body.items)>0:
        validated=[]
        for line in body.items:
            item=await db.restaurant_menu.find_one({"_id":_object_id_or_404(line.menu_item_id,"Menu item"),"restaurant_id":body.restaurant_id})
            if not item or not item.get("available",True): raise HTTPException(status_code=409,detail="A cart item is no longer available")
            validated.append({"menu_item_id":line.menu_item_id,"quantity":line.quantity,"variant_id":line.variant_id,"add_on_ids":line.add_on_ids,"instructions":line.instructions})
    else: validated=[]
    doc={"user_id":user["id"],"restaurant_id":body.restaurant_id,"items":validated,"updated_at":now_utc()}
    await db.restaurant_carts.update_one({"user_id":user["id"]},{"$set":doc},upsert=True)
    return {"saved":True,"restaurant_id":body.restaurant_id,"item_count":len(validated)}

@api.delete("/restaurant/cart")
async def clear_restaurant_cart(user: dict = Depends(get_current_user)):
    await db.restaurant_carts.delete_one({"user_id":user["id"]})
    return {"cleared":True}

@api.post("/restaurant/orders")
async def create_restaurant_order(body: RestaurantOrderIn, user: dict = Depends(get_current_user)):
    prior = await db.restaurant_orders.find_one({"customer_id": user["id"], "idempotency_key": body.idempotency_key})
    if prior:
        return doc_out(prior)
    restaurant = await _restaurant_or_404(body.restaurant_id)
    if restaurant.get("status") != "approved" or not restaurant.get("available", False):
        raise HTTPException(status_code=409, detail="Restaurant is not accepting orders")
    if body.fulfillment == "delivery" and not restaurant.get("delivery_available", True):
        raise HTTPException(status_code=400, detail="Delivery is unavailable; choose pickup if supported")
    if body.fulfillment == "pickup" and not restaurant.get("pickup_available", True):
        raise HTTPException(status_code=400, detail="Pickup is unavailable")
    if body.payment_method not in restaurant.get("payment_methods", ["cod", "pickup"]):
        raise HTTPException(status_code=400, detail="This restaurant does not support the selected payment method")
    if body.payment_method == "pickup" and body.fulfillment != "pickup":
        raise HTTPException(status_code=400, detail="Pay-at-pickup requires pickup fulfilment")
    if body.payment_method == "razorpay" and not (os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET")):
        raise HTTPException(status_code=503, detail="Online payments are not configured")
    address = body.delivery_address
    if body.address_id:
        addr = await db.addresses.find_one({"_id": _object_id_or_404(body.address_id, "Address"), "user_id": user["id"]})
        if not addr:
            raise HTTPException(status_code=404, detail="Saved address not found")
        address = ", ".join([addr.get(k, "") for k in ("address_line", "city", "state", "pincode") if addr.get(k)])
    if body.fulfillment == "delivery" and not address:
        raise HTTPException(status_code=422, detail="Delivery address is required")
    item_rows=[]; subtotal=0.0
    for line in body.items:
        item = await db.restaurant_menu.find_one({"_id": _object_id_or_404(line.menu_item_id, "Menu item"), "restaurant_id": body.restaurant_id})
        if not item or not item.get("available", True):
            raise HTTPException(status_code=409, detail="A menu item is unavailable; refresh your cart")
        base_price=float(item["price"]); selected_addons=[]
        available_addons={str(a.get("id")):a for a in item.get("add_ons", []) if isinstance(a, dict) and a.get("id")}
        for aid in line.add_on_ids:
            addon=available_addons.get(aid)
            if not addon: raise HTTPException(status_code=400, detail="Invalid menu add-on")
            base_price += float(addon.get("price", 0)); selected_addons.append({"id":aid,"name":addon.get("name","Add-on"),"price":float(addon.get("price",0))})
        selected_variant=None
        if line.variant_id:
            variant=next((v for v in item.get("variants",[]) if isinstance(v,dict) and str(v.get("id"))==line.variant_id),None)
            if not variant: raise HTTPException(status_code=400, detail="Invalid menu variant")
            base_price=float(variant.get("price",base_price))+sum(x["price"] for x in selected_addons)
            selected_variant={"id":line.variant_id,"name":variant.get("name","Variant"),"price":float(variant.get("price",base_price))}
        subtotal += base_price*line.quantity
        item_rows.append({"menu_item_id":line.menu_item_id,"name":item["name"],"quantity":line.quantity,"unit_price":round(base_price,2),"line_total":round(base_price*line.quantity,2),"variant":selected_variant,"add_ons":selected_addons,"instructions":line.instructions,"image_url":item.get("image_url")})
    if subtotal < float(restaurant.get("min_order",0)):
        raise HTTPException(status_code=400, detail=f"Minimum order is ₹{restaurant.get('min_order',0)}")
    totals=calculate_restaurant_totals(subtotal, float(restaurant.get("delivery_fee",0)), float(restaurant.get("tax_rate",5)), body.fulfillment)
    order={"ref":"FO-"+uuid.uuid4().hex[:10].upper(),"customer_id":user["id"],"restaurant_id":body.restaurant_id,"restaurant_name":restaurant["name"],"restaurant_owner_id":restaurant["owner_id"],"items":item_rows,"subtotal":totals["subtotal"],"delivery_fee":totals["delivery_fee"],"tax":totals["tax"],"total":totals["total"],"currency":"INR","fulfillment":body.fulfillment,"delivery_address":address or "Pickup","contact_name":body.contact_name,"contact_phone":body.contact_phone,"notes":body.notes,"status":"pending_payment" if body.payment_method=="razorpay" else "placed","payment_method":body.payment_method,"payment_status":"pending" if body.payment_method=="razorpay" else ("cod_pending" if body.payment_method=="cod" else "pay_at_pickup_pending"),"idempotency_key":body.idempotency_key,"status_history":[{"status":"pending_payment" if body.payment_method=="razorpay" else "placed","at":now_utc(),"note":"Order created; awaiting restaurant acceptance/payment as applicable."}],"created_at":now_utc(),"updated_at":now_utc()}
    try:
        result=await db.restaurant_orders.insert_one(order); order["_id"]=result.inserted_id
    except Exception:
        # Handle concurrent duplicate idempotency-key submissions safely.
        prior=await db.restaurant_orders.find_one({"customer_id":user["id"],"idempotency_key":body.idempotency_key})
        if prior: return doc_out(prior)
        raise
    await db.restaurant_carts.delete_one({"user_id":user["id"],"restaurant_id":body.restaurant_id})
    return doc_out(order)

@api.get("/restaurant/orders/mine")
async def my_restaurant_orders(user: dict = Depends(get_current_user)):
    return [doc_out(x) async for x in db.restaurant_orders.find({"customer_id":user["id"]}).sort("created_at",-1).limit(200)]

@api.get("/restaurants/{restaurant_id}/orders")
async def restaurant_orders(restaurant_id: str, user: dict = Depends(get_current_user)):
    restaurant=await _restaurant_or_404(restaurant_id); _restaurant_owner(restaurant,user)
    return [doc_out(x) async for x in db.restaurant_orders.find({"restaurant_id":restaurant_id}).sort("created_at",-1).limit(500)]

@api.patch("/restaurant/orders/{order_id}/status")
async def update_restaurant_order_status(order_id: str, body: RestaurantStatusIn, user: dict = Depends(get_current_user)):
    oid=_object_id_or_404(order_id,"Order")
    order=await db.restaurant_orders.find_one({"_id":oid})
    if not order: raise HTTPException(status_code=404,detail="Order not found")
    if user.get("role")!="admin" and order.get("restaurant_owner_id")!=user.get("id"):
        raise HTTPException(status_code=403,detail="Only this restaurant's owner can update its orders")
    allowed={"placed":{"accepted","rejected","cancelled"},"accepted":{"preparing","cancelled"},"preparing":{"ready","cancelled"},"ready":{"picked_up","out_for_delivery","delivered"},"out_for_delivery":{"delivered"}}
    if body.status not in allowed.get(order.get("status"),set()):
        raise HTTPException(status_code=409,detail=f"Invalid order status transition: {order.get('status')} → {body.status}")
    update={"status":body.status,"updated_at":now_utc()}
    if body.status=="rejected": update["rejection_note"]=body.note
    await db.restaurant_orders.update_one({"_id":oid},{"$set":update,"$push":{"status_history":{"status":body.status,"at":now_utc(),"note":body.note}}})
    return doc_out(await db.restaurant_orders.find_one({"_id":oid}))

@api.post("/restaurant/orders/{order_id}/cancel")
async def cancel_restaurant_order(order_id: str, user: dict = Depends(get_current_user)):
    oid=_object_id_or_404(order_id,"Order"); order=await db.restaurant_orders.find_one({"_id":oid,"customer_id":user["id"]})
    if not order: raise HTTPException(status_code=404,detail="Order not found")
    if order.get("status") not in {"placed","pending_payment"} or order.get("payment_status")=="paid":
        raise HTTPException(status_code=409,detail="This order can no longer be cancelled online; contact support")
    await db.restaurant_orders.update_one({"_id":oid},{"$set":{"status":"cancelled","updated_at":now_utc()},"$push":{"status_history":{"status":"cancelled","at":now_utc(),"note":"Cancelled by customer"}}})
    return doc_out(await db.restaurant_orders.find_one({"_id":oid}))

@api.get("/restaurant/payments/config")
async def restaurant_payment_config():
    # Only public key IDs may be returned; private credentials remain server-side.
    return {"razorpay_enabled":bool(os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET")),"razorpay_key_id":os.environ.get("RAZORPAY_KEY_ID") if os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET") else None,"supported_methods":["cod","pickup"] + (["razorpay"] if os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET") else [])}

@api.post("/restaurant/orders/{order_id}/payment-intent")
async def create_restaurant_payment_intent(order_id: str, user: dict = Depends(get_current_user)):
    oid=_object_id_or_404(order_id,"Order"); order=await db.restaurant_orders.find_one({"_id":oid,"customer_id":user["id"]})
    if not order: raise HTTPException(status_code=404,detail="Order not found")
    key_id=os.environ.get("RAZORPAY_KEY_ID"); key_secret=os.environ.get("RAZORPAY_KEY_SECRET")
    if not key_id or not key_secret:
        raise HTTPException(status_code=503,detail="Online payments are not configured. Use COD or pickup payment if the restaurant supports it.")
    if order.get("payment_method")!="razorpay" or order.get("payment_status")!="pending":
        raise HTTPException(status_code=409,detail="Order is not awaiting online payment")
    import requests as http_requests
    try:
        resp=http_requests.post("https://api.razorpay.com/v1/orders",auth=(key_id,key_secret),json={"amount":int(round(order["total"]*100)),"currency":"INR","receipt":order["ref"],"notes":{"comein_order_id":str(order["_id"])}},timeout=15)
        if resp.status_code>=400: raise RuntimeError("Gateway rejected request")
        payload=resp.json()
    except Exception:
        raise HTTPException(status_code=502,detail="Payment gateway is unavailable; no payment was confirmed")
    await db.restaurant_payments.insert_one({"order_id":str(order["_id"]),"customer_id":user["id"],"gateway":"razorpay","gateway_order_id":payload["id"],"amount":order["total"],"currency":"INR","status":"created","created_at":now_utc(),"updated_at":now_utc()})
    return {"gateway":"razorpay","key_id":key_id,"gateway_order_id":payload["id"],"amount":payload["amount"],"currency":payload["currency"],"order_ref":order["ref"]}

@api.post("/restaurant/orders/{order_id}/payment-retry")
async def retry_restaurant_payment(order_id: str, user: dict = Depends(get_current_user)):
    oid=_object_id_or_404(order_id,"Order")
    order=await db.restaurant_orders.find_one({"_id":oid,"customer_id":user["id"]})
    if not order: raise HTTPException(status_code=404,detail="Order not found")
    if order.get("payment_status") not in {"failed","pending"} or order.get("payment_method")!="razorpay":
        raise HTTPException(status_code=409,detail="This order is not eligible for online payment retry")
    if not os.environ.get("RAZORPAY_KEY_ID") or not os.environ.get("RAZORPAY_KEY_SECRET"):
        raise HTTPException(status_code=503,detail="Online payment is not configured")
    await db.restaurant_orders.update_one({"_id":oid},{"$set":{"payment_status":"pending","status":"pending_payment","updated_at":now_utc()}})
    return {"retry_allowed":True,"order_id":str(oid),"message":"Create a new payment intent to retry. No payment has been confirmed."}

@api.post("/restaurant/payments/verify")
async def verify_restaurant_payment(body: PaymentVerifyIn, user: dict = Depends(get_current_user)):
    oid=_object_id_or_404(body.order_id,"Order"); order=await db.restaurant_orders.find_one({"_id":oid,"customer_id":user["id"]})
    if not order: raise HTTPException(status_code=404,detail="Order not found")
    secret=os.environ.get("RAZORPAY_KEY_SECRET")
    if not secret: raise HTTPException(status_code=503,detail="Payment verification is not configured")
    payment_record=await db.restaurant_payments.find_one({"order_id":str(oid),"gateway_order_id":body.razorpay_order_id,"gateway":"razorpay"})
    if not payment_record: raise HTTPException(status_code=403,detail="Gateway order does not belong to this Come-In order")
    if round(float(payment_record.get("amount", -1)), 2) != round(float(order.get("total", -2)), 2):
        raise HTTPException(status_code=409, detail="Payment amount does not match the order total")
    if payment_record.get("status") == "paid":
        if payment_record.get("gateway_payment_id") == body.razorpay_payment_id and order.get("payment_status") == "paid":
            return {"verified": True, "order": doc_out(order)}
        raise HTTPException(status_code=409, detail="This payment order has already been completed")
    expected=hmac.new(secret.encode(),f"{body.razorpay_order_id}|{body.razorpay_payment_id}".encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,body.razorpay_signature):
        await db.restaurant_payments.update_one({"gateway_order_id":body.razorpay_order_id},{"$set":{"status":"verification_failed","updated_at":now_utc()}})
        raise HTTPException(status_code=400,detail="Payment signature verification failed")
    await db.restaurant_payments.update_one({"gateway_order_id":body.razorpay_order_id},{"$set":{"status":"paid","gateway_payment_id":body.razorpay_payment_id,"updated_at":now_utc()}})
    await db.restaurant_orders.update_one({"_id":oid},{"$set":{"payment_status":"paid","status":"placed","updated_at":now_utc()},"$push":{"status_history":{"status":"placed","at":now_utc(),"note":"Payment verified server-side"}}})
    return {"verified":True,"order":doc_out(await db.restaurant_orders.find_one({"_id":oid}))}

def _captured_payment_matches_order(payment: dict, order: Optional[dict], entity: dict) -> bool:
    """Return whether a captured Razorpay payload matches our persisted INR order."""
    if not order or entity.get("currency") != "INR":
        return False
    try:
        expected_paise = int(round(float(payment.get("amount", -1)) * 100))
        payment_amount = round(float(payment.get("amount", -1)), 2)
        order_amount = round(float(order.get("total", -2)), 2)
    except (TypeError, ValueError, OverflowError):
        return False
    return (
        isinstance(entity.get("amount"), int)
        and not isinstance(entity.get("amount"), bool)
        and entity.get("amount") == expected_paise
        and payment_amount >= 0
        and order_amount == payment_amount
    )


@api.post("/restaurant/payments/razorpay-webhook")
async def razorpay_webhook(request: Request):
    secret=os.environ.get("RAZORPAY_WEBHOOK_SECRET")
    if not secret: raise HTTPException(status_code=503,detail="Payment webhook is not configured")
    raw=await request.body(); signature=request.headers.get("X-Razorpay-Signature","")
    expected=hmac.new(secret.encode(),raw,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature): raise HTTPException(status_code=400,detail="Invalid webhook signature")
    try: payload=json.loads(raw)
    except Exception: raise HTTPException(status_code=400,detail="Invalid webhook payload")
    event_id = request.headers.get("X-Razorpay-Event-Id") or payload.get("id")
    if event_id and await db.restaurant_payment_events.find_one({"event_id": event_id}):
        return {"received": True, "duplicate": True}
    event=payload.get("event",""); entity=payload.get("payload",{}).get("payment",{}).get("entity",{})
    if event=="payment.captured" and entity.get("order_id"):
        payment=await db.restaurant_payments.find_one({"gateway_order_id":entity["order_id"]})
        if payment:
            order = await db.restaurant_orders.find_one({"_id":ObjectId(payment["order_id"])})
            # A signed webhook is authentic, but still validate the payment belongs
            # to this order and has the exact expected currency and amount.
            if not _captured_payment_matches_order(payment, order, entity):
                logger.error("Ignoring captured payment with mismatched order amount/currency")
            else:
                await db.restaurant_payments.update_one({"_id":payment["_id"],"status":{"$ne":"paid"}},{"$set":{"status":"paid","gateway_payment_id":entity.get("id"),"updated_at":now_utc()}})
                await db.restaurant_orders.update_one({"_id":ObjectId(payment["order_id"]),"payment_status":{"$ne":"paid"}},{"$set":{"payment_status":"paid","status":"placed","updated_at":now_utc()}})
    elif event in ("payment.failed",):
        if entity.get("order_id"):
            payment=await db.restaurant_payments.find_one({"gateway_order_id":entity["order_id"]})
            if payment:
                await db.restaurant_payments.update_one({"_id":payment["_id"],"status":{"$ne":"paid"}},{"$set":{"status":"failed","updated_at":now_utc()}})
                await db.restaurant_orders.update_one({"_id":ObjectId(payment["order_id"]),"payment_status":{"$ne":"paid"}},{"$set":{"payment_status":"failed","updated_at":now_utc()}})
    elif event in ("refund.processed", "refund.failed"):
        refund=payload.get("payload",{}).get("refund",{}).get("entity",{})
        payment_id=refund.get("payment_id")
        if payment_id:
            payment=await db.restaurant_payments.find_one({"gateway_payment_id":payment_id})
            if payment:
                refund_status="refunded" if event=="refund.processed" else "refund_failed"
                await db.restaurant_payments.update_one({"_id":payment["_id"]},{"$set":{"refund_status":refund_status,"refund_id":refund.get("id"),"updated_at":now_utc()}})
                await db.restaurant_orders.update_one({"_id":ObjectId(payment["order_id"])},{"$set":{"refund_status":refund_status,"updated_at":now_utc()}})
    # Record the event only after processing, so transient DB/provider errors do
    # not permanently suppress Razorpay retries. Unique index resolves duplicates.
    if event_id:
        try:
            await db.restaurant_payment_events.insert_one({"event_id": event_id, "event": event, "received_at": now_utc()})
        except Exception as exc:
            if getattr(exc, "code", None) == 11000:
                return {"received": True, "duplicate": True}
            raise
    return {"received":True}

@api.post("/restaurants/{restaurant_id}/reviews")
async def create_restaurant_review(restaurant_id: str, body: RestaurantReviewIn, user: dict = Depends(get_current_user)):
    restaurant=await _restaurant_or_404(restaurant_id)
    completed=await db.restaurant_orders.find_one({"restaurant_id":restaurant_id,"customer_id":user["id"],"status":{"$in":["delivered","picked_up"]}})
    if not completed: raise HTTPException(status_code=403,detail="Only customers with a delivered order can review this restaurant")
    prior=await db.restaurant_reviews.find_one({"restaurant_id":restaurant_id,"customer_id":user["id"]})
    review={"restaurant_id":restaurant_id,"customer_id":user["id"],"customer_name":user.get("name","Customer"),"rating":body.rating,"comment":body.comment,"created_at":now_utc()}
    if prior: await db.restaurant_reviews.update_one({"_id":prior["_id"]},{"$set":review})
    else: await db.restaurant_reviews.insert_one(review)
    reviews=[x async for x in db.restaurant_reviews.find({"restaurant_id":restaurant_id})]
    avg=round(sum(x["rating"] for x in reviews)/len(reviews),2) if reviews else 0
    await db.restaurants.update_one({"_id":restaurant["_id"]},{"$set":{"rating":avg,"review_count":len(reviews)}})
    return {"saved":True,"rating":avg,"review_count":len(reviews)}

class RestaurantSupportIn(BaseModel):
    order_id: Optional[str] = None
    category: Literal["order", "payment", "refund", "restaurant", "other"] = "order"
    message: str = Field(min_length=5, max_length=2000)

@api.post("/restaurant/support")
async def create_restaurant_support(body: RestaurantSupportIn, user: dict = Depends(get_current_user)):
    order_id=None
    if body.order_id:
        order=await db.restaurant_orders.find_one({"_id":_object_id_or_404(body.order_id,"Order"),"customer_id":user["id"]})
        if not order: raise HTTPException(status_code=404,detail="Order not found")
        order_id=str(order["_id"])
    ticket={"ref":"SUP-"+uuid.uuid4().hex[:10].upper(),"user_id":user["id"],"order_id":order_id,"category":body.category,"message":body.message,"status":"open","created_at":now_utc(),"updated_at":now_utc(),"history":[{"status":"open","at":now_utc()}]}
    result=await db.restaurant_support.insert_one(ticket);ticket["_id"]=result.inserted_id
    return doc_out(ticket)

@api.get("/restaurant/support/mine")
async def my_restaurant_support(user: dict = Depends(get_current_user)):
    return [doc_out(x) async for x in db.restaurant_support.find({"user_id":user["id"]}).sort("created_at",-1).limit(200)]

@api.get("/admin/restaurant/support")
async def admin_restaurant_support(_: dict = Depends(require_role("admin"))):
    return [doc_out(x) async for x in db.restaurant_support.find().sort("created_at",-1).limit(1000)]

@api.patch("/admin/restaurant/support/{ticket_id}")
async def admin_update_restaurant_support(ticket_id: str, body: dict, _: dict = Depends(require_role("admin"))):
    status_value=body.get("status")
    if status_value not in {"open","in_progress","resolved","closed"}: raise HTTPException(status_code=422,detail="Invalid support status")
    oid=_object_id_or_404(ticket_id,"Support ticket"); ticket=await db.restaurant_support.find_one({"_id":oid})
    if not ticket: raise HTTPException(status_code=404,detail="Support ticket not found")
    await db.restaurant_support.update_one({"_id":oid},{"$set":{"status":status_value,"updated_at":now_utc()},"$push":{"history":{"status":status_value,"at":now_utc()}}})
    return doc_out(await db.restaurant_support.find_one({"_id":oid}))

@api.post("/admin/restaurant/orders/{order_id}/refund")
async def admin_refund_restaurant_order(order_id: str, _: dict = Depends(require_role("admin"))):
    oid=_object_id_or_404(order_id,"Order"); order=await db.restaurant_orders.find_one({"_id":oid})
    if not order: raise HTTPException(status_code=404,detail="Order not found")
    if order.get("payment_status")!="paid": raise HTTPException(status_code=409,detail="Only verified paid orders can be refunded")
    payment=await db.restaurant_payments.find_one({"order_id":str(oid),"status":"paid"})
    if not payment or not payment.get("gateway_payment_id"): raise HTTPException(status_code=409,detail="No verified online payment is linked to this order")
    if payment.get("refund_status") in {"pending", "processed", "refunded"} or order.get("refund_status") in {"pending", "processed", "refunded"}:
        raise HTTPException(status_code=409,detail="A refund is already pending or completed")
    key_id=os.environ.get("RAZORPAY_KEY_ID"); secret=os.environ.get("RAZORPAY_KEY_SECRET")
    if not key_id or not secret: raise HTTPException(status_code=503,detail="Refund gateway is not configured")
    import requests as http_requests
    try:
        resp=http_requests.post(f"https://api.razorpay.com/v1/payments/{payment['gateway_payment_id']}/refund",auth=(key_id,secret),json={"amount":int(round(order["total"]*100)),"notes":{"comein_order_id":str(oid)}},timeout=15)
        if resp.status_code>=400: raise RuntimeError("Gateway rejected refund")
        refund=resp.json()
    except Exception:
        await db.restaurant_payments.update_one({"_id":payment["_id"]},{"$set":{"refund_status":"refund_requested_failed","updated_at":now_utc()}})
        raise HTTPException(status_code=502,detail="Refund request failed at the gateway; check provider dashboard before retrying")
    await db.restaurant_payments.update_one({"_id":payment["_id"]},{"$set":{"refund_status":refund.get("status","pending"),"refund_id":refund.get("id"),"updated_at":now_utc()}})
    await db.restaurant_orders.update_one({"_id":oid},{"$set":{"refund_status":refund.get("status","pending"),"updated_at":now_utc()}})
    return {"refund_requested":True,"refund_status":refund.get("status","pending"),"refund_id":refund.get("id"),"message":"Provider refund status is pending confirmation; check webhook/provider dashboard."}

@api.get("/admin/restaurant/orders")
async def admin_restaurant_orders(_: dict = Depends(require_role("admin"))):
    return [doc_out(x) async for x in db.restaurant_orders.find().sort("created_at",-1).limit(2000)]

@api.get("/admin/restaurants")
async def admin_restaurants(_: dict = Depends(require_role("admin"))):
    return [doc_out(x) async for x in db.restaurants.find().sort("created_at",-1).limit(1000)]

@api.patch("/admin/restaurants/{restaurant_id}/status")
async def admin_restaurant_status(restaurant_id: str, body: dict, _: dict = Depends(require_role("admin"))):
    status_value=body.get("status")
    if status_value not in {"pending","approved","suspended"}: raise HTTPException(status_code=422,detail="Invalid restaurant status")
    restaurant=await _restaurant_or_404(restaurant_id)
    await db.restaurants.update_one({"_id":restaurant["_id"]},{"$set":{"status":status_value,"available":bool(status_value=="approved" and body.get("available",False)),"updated_at":now_utc()}})
    return doc_out(await _restaurant_or_404(restaurant_id))

# ---------------------------------------------------------------------------
# Startup: indexes + admin seed
# ---------------------------------------------------------------------------


@app.on_event("startup")
async def _startup():
    await db.users.create_index("email", unique=True)
    await db.shops.create_index("owner_id")
    await db.shops.create_index("status")
    await db.products.create_index("shop_id")
    await db.products.create_index("owner_id")
    await db.orders.create_index("customer_id")
    await db.orders.create_index("shop_id")
    await db.files.create_index("owner_id")
    await db.restaurants.create_index("owner_id")
    await db.restaurants.create_index([("status", 1), ("available", 1), ("city", 1)])
    await db.restaurant_menu.create_index([("restaurant_id", 1), ("available", 1)])
    await db.addresses.create_index([("user_id", 1), ("is_default", -1)])
    await db.restaurant_orders.create_index([("customer_id", 1), ("created_at", -1)])
    await db.restaurant_orders.create_index([("restaurant_id", 1), ("created_at", -1)])
    await db.restaurant_orders.create_index([("customer_id", 1), ("idempotency_key", 1)], unique=True)
    await db.restaurant_payments.create_index("gateway_order_id", unique=True, sparse=True)
    await db.restaurant_payment_events.create_index("event_id", unique=True, sparse=True)
    await db.restaurant_reviews.create_index([("restaurant_id", 1), ("customer_id", 1)], unique=True)
    await db.password_resets.create_index("expires_at", expireAfterSeconds=0)
    await db.restaurant_support.create_index([("user_id", 1), ("created_at", -1)])
    await db.restaurant_carts.create_index("user_id", unique=True)

    # Warm up object storage so uploads work on the first request
    try:
        init_storage()
    except Exception as e:
        logger.warning("Object storage warm-up failed: %s", e)

    # Never seed a predictable administrator account. Explicit deployment
    # configuration is required before an admin can be created or rotated.
    admin_email = (os.environ.get("ADMIN_EMAIL") or "").strip().lower()
    admin_password = os.environ.get("ADMIN_PASSWORD") or ""
    if admin_email and admin_password:
        if len(admin_password) < 16:
            raise RuntimeError("ADMIN_PASSWORD must be at least 16 characters")
        existing = await db.users.find_one({"email": admin_email})
        if existing is None:
            await db.users.insert_one({
                "name": "Come In Admin", "email": admin_email, "phone": "",
                "password_hash": hash_password(admin_password), "role": "admin",
                "created_at": now_utc(), "updated_at": now_utc(),
            })
            logger.info("Seeded configured admin account")
        elif existing.get("role") == "admin" and not verify_password(admin_password, existing.get("password_hash", "")):
            await db.users.update_one({"_id": existing["_id"]}, {"$set": {
                "password_hash": hash_password(admin_password), "updated_at": now_utc()
            }})
            logger.info("Rotated configured admin credentials")
    else:
        logger.warning("ADMIN_EMAIL/ADMIN_PASSWORD not configured; admin account seeding is disabled")


@app.on_event("shutdown")
async def _shutdown():
    client.close()


# ---------------------------------------------------------------------------
# Mount router + CORS
# ---------------------------------------------------------------------------

app.include_router(api)

cors_origins_env = os.environ.get("CORS_ORIGINS", "*")
cors_origins = [o.strip() for o in cors_origins_env.split(",")] if cors_origins_env else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=False,  # Bearer tokens — no cookies
    allow_methods=["*"],
    allow_headers=["*"],
)
