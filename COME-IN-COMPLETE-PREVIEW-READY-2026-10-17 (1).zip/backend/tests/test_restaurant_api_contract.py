"""Static route contract checks; these do not replace live API/database integration tests."""
import ast
from pathlib import Path

SERVER = Path(__file__).parents[1] / "server.py"
TREE = ast.parse(SERVER.read_text())
ROUTES = set()
for node in ast.walk(TREE):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute):
                if isinstance(dec.func.value, ast.Name) and dec.func.value.id == "api":
                    if dec.args and isinstance(dec.args[0], ast.Constant):
                        ROUTES.add((dec.func.attr.upper(), dec.args[0].value))


def test_restaurant_discovery_and_menu_routes_exist():
    assert ("GET", "/restaurants") in ROUTES
    assert ("GET", "/restaurants/{restaurant_id}") in ROUTES
    assert ("GET", "/restaurants/{restaurant_id}/menu") in ROUTES
    assert ("POST", "/restaurants/{restaurant_id}/menu") in ROUTES


def test_server_order_and_cart_routes_exist():
    assert ("GET", "/restaurant/cart") in ROUTES
    assert ("PUT", "/restaurant/cart") in ROUTES
    assert ("POST", "/restaurant/orders") in ROUTES
    assert ("GET", "/restaurant/orders/mine") in ROUTES
    assert ("PATCH", "/restaurant/orders/{order_id}/status") in ROUTES


def test_auth_address_payment_and_support_routes_exist():
    assert ("POST", "/auth/password/forgot") in ROUTES
    assert ("POST", "/auth/password/reset") in ROUTES
    assert ("GET", "/addresses") in ROUTES
    assert ("POST", "/restaurant/orders/{order_id}/payment-intent") in ROUTES
    assert ("POST", "/restaurant/payments/verify") in ROUTES
    assert ("POST", "/restaurant/payments/razorpay-webhook") in ROUTES
    assert ("POST", "/restaurant/support") in ROUTES


def test_admin_seeding_has_no_predictable_default_password():
    source = SERVER.read_text()
    assert 'os.environ.get("ADMIN_PASSWORD", "ComeIn@2026Admin")' not in source
    assert 'ADMIN_PASSWORD must be at least 16 characters' in source
    assert 'admin account seeding is disabled' in source


def test_payment_verification_checks_amount_and_webhook_deduplication():
    source = SERVER.read_text()
    assert 'Payment amount does not match the order total' in source
    assert 'This payment order has already been completed' in source
    assert 'restaurant_payment_events.create_index("event_id", unique=True, sparse=True)' in source
    assert '"duplicate": True' in source


def test_payment_webhook_validates_captured_amount_and_currency():
    source = SERVER.read_text()
    assert 'entity.get("currency") != "INR"' in source
    assert 'entity.get("amount") == expected_paise' in source
    assert 'payment_status":{"$ne":"paid"}' in source

def test_webhook_event_is_recorded_after_processing_for_retry_safety():
    source = SERVER.read_text()
    start = source.index('async def razorpay_webhook')
    end = source.index('@api.post("/restaurants/{restaurant_id}/reviews")', start)
    webhook = source[start:end]
    assert webhook.index('event=="payment.captured"') < webhook.index('restaurant_payment_events.insert_one')
    assert 'if event_id and await db.restaurant_payment_events.find_one' in webhook


def test_captured_payment_amount_currency_and_order_match_helper():
    # Execute the actual pure validation helper from the source AST without importing
    # server.py (which requires configured MongoDB and optional backend packages).
    import ast
    helper = next(
        node for node in TREE.body
        if isinstance(node, ast.FunctionDef) and node.name == "_captured_payment_matches_order"
    )
    module = ast.Module(body=[helper], type_ignores=[])
    namespace = {"Optional": __import__("typing").Optional}
    exec(compile(module, str(SERVER), "exec"), namespace)
    matches = namespace["_captured_payment_matches_order"]
    payment = {"amount": 125.50}
    order = {"total": 125.50}
    assert matches(payment, order, {"currency": "INR", "amount": 12550})
    assert not matches(payment, order, {"currency": "USD", "amount": 12550})
    assert not matches(payment, order, {"currency": "INR", "amount": 12549})
    assert not matches(payment, {"total": 125.51}, {"currency": "INR", "amount": 12550})
    assert not matches(payment, None, {"currency": "INR", "amount": 12550})
    assert not matches({"amount": "not-a-number"}, order, {"currency": "INR", "amount": 12550})
    assert not matches(payment, order, {"currency": "INR", "amount": True})
