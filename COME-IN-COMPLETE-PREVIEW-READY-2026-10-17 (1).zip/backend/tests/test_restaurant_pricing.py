import pytest
from restaurant_pricing import calculate_restaurant_totals


def test_delivery_totals_rounding():
    assert calculate_restaurant_totals(249.99, 20, 5, "delivery") == {
        "subtotal": 249.99, "delivery_fee": 20.0, "tax": 12.5, "total": 282.49
    }


def test_pickup_does_not_charge_delivery():
    assert calculate_restaurant_totals(100, 35, 5, "pickup") == {
        "subtotal": 100.0, "delivery_fee": 0.0, "tax": 5.0, "total": 105.0
    }


@pytest.mark.parametrize("subtotal,fee,tax", [(-1, 0, 5), (10, -1, 5), (10, 0, 31)])
def test_invalid_pricing_rejected(subtotal, fee, tax):
    with pytest.raises(ValueError):
        calculate_restaurant_totals(subtotal, fee, tax, "delivery")
