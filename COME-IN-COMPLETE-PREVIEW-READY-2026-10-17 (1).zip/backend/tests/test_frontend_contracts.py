"""Static frontend contracts; runtime behavior still needs Expo/device testing."""
from pathlib import Path

ROOT = Path(__file__).parents[2]

def test_expo_public_backend_url_is_documented_and_used():
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    env = (ROOT / "frontend/.env.example").read_text()
    assert "process.env.EXPO_PUBLIC_BACKEND_URL" in api
    assert "EXPO_PUBLIC_BACKEND_URL=http://localhost:8000" in env
    assert "Backend URL is not configured" in api
    assert 'if (window.location.port === "3000") return ""' in api

def test_auth_token_uses_secure_storage_consistently():
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    auth = (ROOT / "frontend/src/store/auth.tsx").read_text()
    cart = (ROOT / "frontend/src/restaurant/cart.ts").read_text()
    assert "storage.secureGet<string>(TOKEN_KEY" in api
    assert "storage.secureSet(TOKEN_KEY, token)" in auth
    assert "storage.secureRemove(TOKEN_KEY)" in auth
    assert "storage.secureGet<string>(TOKEN_KEY" in cart

def test_frontend_exposes_typecheck_and_production_web_build_scripts():
    import json
    package = json.loads((ROOT / "frontend/package.json").read_text())
    assert package["scripts"]["typecheck"] == "tsc --noEmit"
    assert package["scripts"]["build:web"] == "expo export --platform web"


def test_restaurant_checkout_never_creates_local_demo_orders():
    checkout = (ROOT / "frontend/app/restaurant/checkout.tsx").read_text()
    assert "No order was created" in checkout
    assert "ORDERS_KEY" not in checkout
    assert "storage.setItem" not in checkout
    assert "createLiveOrder" in checkout
    assert "new Set(lines.map(line=>line.restaurantId)).size!==1" in checkout


def test_auth_persistence_failure_is_not_silently_accepted():
    auth = (ROOT / "frontend/src/store/auth.tsx").read_text()
    assert "const saved = await storage.secureSet(TOKEN_KEY, token)" in auth
    assert "could not save the session securely" in auth
    assert "Keep an already-hydrated user signed in through transient network/5xx errors" in auth


def test_upload_handles_missing_backend_and_network_errors():
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    upload = api.split('async upload(', 1)[1].split('\n  },', 1)[0]
    assert "if (!API_BASE)" in upload
    assert "Could not upload the image" in upload


def test_app_does_not_globally_suppress_runtime_diagnostics():
    layout = (ROOT / "frontend/app/_layout.tsx").read_text()
    assert "LogBox.ignoreAllLogs(true)" not in layout


def test_shopping_and_restaurant_carts_use_distinct_storage_keys():
    shopping = (ROOT / "frontend/src/store/cart.tsx").read_text()
    restaurant = (ROOT / "frontend/src/restaurant/cart.ts").read_text()
    assert '"@comein_cart_v1"' in shopping
    assert "'@comein_restaurant_cart_v1'" in restaurant


def test_shopping_home_theme_contract_and_separate_mode_routes():
    home = (ROOT / "frontend/app/(tabs)/index.tsx").read_text()
    theme = (ROOT / "frontend/src/theme.ts").read_text()
    tabs = (ROOT / "frontend/app/(tabs)/_layout.tsx").read_text()
    shops = (ROOT / "frontend/app/shops.tsx").read_text()
    for marker in (
        'testID="home-filter-button"',
        'testID="online-shops-card"',
        'testID="offline-shops-card"',
        'testID="restaurant-mode-card"',
        'testID="home-services-card"',
        'testID="request-anything-card"',
        'data={["fruits-veggies", "dairy-breakfast", "snacks", "beverages", "bakery", "personal-care"]',
        'testID="header-language"',
        'testID="header-voice-search"',
        'testID="fresh-groceries-banner"',
        'router.push("/restaurant")',
        'router.push("/services")',
    ):
        assert marker in home
    assert 'brandHeader: "#FFE34F"' in theme
    assert 'surface: "#EFFBF5"' in theme
    # Match the reference hierarchy: yellow brand row, then mint search surface.
    assert home.index("{/* Sticky Header */}") < home.index("{/* Search sits on the mint page surface")
    assert 'testID="location-selector"' in home
    assert 'styles.searchArea' in home
    assert "discoveryTitle" not in home
    assert 'backgroundColor: colors.brandForest' in tabs
    assert 'useLocalSearchParams<{ type?: string }>()' in shops
    assert 'params.type === "online" || params.type === "offline"' in shops


def test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest():
    catalog = (ROOT / "frontend/src/data/catalog.ts").read_text()
    home = (ROOT / "frontend/app/(tabs)/index.tsx").read_text()
    assert 'id: "bakery"' in catalog
    assert 'id: "p-bakery-bread"' not in catalog
    assert 'name: "Fresh Bread Loaf"' not in catalog
    assert 'Voice search unavailable' in home
    assert 'Speech recognition is not configured for this app.' in home

def test_bakery_category_uses_catalog_filter_and_existing_empty_state():
    catalog = (ROOT / "frontend/src/data/catalog.ts").read_text()
    category_screen = (ROOT / "frontend/app/category/[slug].tsx").read_text()
    assert "export function getProductsByCategory(categoryId: string): Product[]" in catalog
    assert "PRODUCTS.filter((p) => p.categoryId === categoryId)" in catalog
    assert 'getProductsByCategory(slug)' in category_screen
    assert 'products.length === 0 ? (' in category_screen
    assert 'No products in this category.' in category_screen
    # No current catalog item claims to be Bakery inventory.
    product_data = catalog.split("export const PRODUCTS: Product[] = [", 1)[1].split("export const QUICK_DELIVERY_PRODUCTS", 1)[0]
    assert 'categoryId: "bakery"' not in product_data


def test_shopping_search_and_cart_contracts_remain_separate_from_restaurant_mode():
    catalog = (ROOT / "frontend/src/data/catalog.ts").read_text()
    search = (ROOT / "frontend/app/(tabs)/search.tsx").read_text()
    shopping_cart = (ROOT / "frontend/src/store/cart.tsx").read_text()
    restaurant_cart = (ROOT / "frontend/src/restaurant/cart.ts").read_text()
    assert "export function searchProducts(query: string): Product[]" in catalog
    assert "searchProducts(" in search
    assert '"@comein_cart_v1"' in shopping_cart
    assert "'@comein_restaurant_cart_v1'" in restaurant_cart
