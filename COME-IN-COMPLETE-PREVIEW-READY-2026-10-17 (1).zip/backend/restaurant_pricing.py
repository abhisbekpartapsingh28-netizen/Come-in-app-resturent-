"""Pure, dependency-free restaurant pricing helpers shared by the API and tests."""
from decimal import Decimal, ROUND_HALF_UP


def money(value: float | int | str) -> float:
    return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def calculate_restaurant_totals(subtotal: float, delivery_fee: float, tax_rate: float, fulfillment: str) -> dict[str, float]:
    """Calculate totals from server-owned menu prices and restaurant fee rules."""
    if subtotal < 0 or delivery_fee < 0 or tax_rate < 0 or tax_rate > 30:
        raise ValueError("Invalid pricing input")
    delivery = money(delivery_fee if fulfillment == "delivery" else 0)
    tax = money(subtotal * tax_rate / 100)
    sub = money(subtotal)
    return {"subtotal": sub, "delivery_fee": delivery, "tax": tax, "total": money(sub + delivery + tax)}
