# COME-IN Theme Update — Pre-Replit Packaging & Verification Report

**Date:** 2026-10-15  
**Scope:** Existing COME-IN project only. No Replit launch, no manual app launch, no production deployment, no payment activity.

## Summary

Updated the existing Shopping Mode home presentation to use a yellow brand header, pale mint-green surfaces, dark-green brand accents, a search row with a working category/filter entry point, four discovery cards, six home-page product categories, and dark-green JavaScript bottom navigation. Existing Request Anything and promotional hero sections remain. Restaurant Mode remains a separate `/restaurant` route with its existing independent theme and cart.

The attached `IMG_4545.png` visible in the working files is a composite of the pink Restaurant Mode screens, not a screenshot of the requested yellow/mint Shopping Mode home. To avoid changing the wrong experience, the Restaurant Mode styling was preserved; the Shopping Mode adjustments follow the explicit requirements in the task text. A pixel-perfect visual comparison to a yellow/mint Shopping Mode master screenshot was therefore not possible from that image.

## Theme requirements reviewed

- **Yellow COME-IN header/branding:** Shopping home header now uses `brandHeader` (`#FFD84D`) behind the existing brand logo.
- **Light mint background:** shared light surface tokens changed to pale mint tones; existing dark-green typography is retained.
- **Dark-green icons/navigation:** shopping bottom navigation (classic Expo Router Tabs path used on web, Android, and iOS below 26) uses dark green with pale-mint inactive labels and yellow active tint. iOS 26+ `NativeTabs` remain system-native; their colors are platform-managed and were not overridden to avoid replacing the existing navigation architecture.
- **Search and filter icon:** search remains navigable to Search; the new filter/sliders control opens Categories.
- **Promotional banner:** existing image-backed promotional hero retained.
- **Four discovery cards:** Online Shops and Offline Shops link to the existing shops page and select the matching tab through the `type` route parameter; Restaurants links to `/restaurant`; Home Services links to `/services`.
- **Six home categories:** home page displays the first six existing catalog categories. The full Categories screen and underlying catalog still retain all eight existing categories, so no product category data was deleted.
- **Request Anything:** existing banner, copy, and `/request` action retained.
- **Bottom navigation:** Home, Categories, Search, Cart, Account remain present. Shopping and Restaurant carts remain separate.

## Files changed in this pass

1. `frontend/src/theme.ts` — mint surface palette, yellow header token, coordinated borders.
2. `frontend/app/(tabs)/index.tsx` — yellow header, search/filter row, four discovery cards, six-category home row; existing hero and Request Anything preserved.
3. `frontend/app/(tabs)/_layout.tsx` — dark-green classic tab bar, yellow active tint, mint inactive tint.
4. `frontend/app/shops.tsx` — reads the Online/Offline type query so the new discovery cards open the relevant shop filter.
5. `backend/tests/test_frontend_contracts.py` — static regression assertions for the requested theme elements and separate routes.
6. `THEME_PACKAGING_TEST_REPORT.md` — this report.

No backend application or payment code was changed in this pass. No task was added to the existing 22-task roadmap.

## Automated checks actually run

| Check | Status | Command / details |
|---|---|---|
| Backend + static frontend-contract test suite | **Passed with skips** | `cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests` — **22 passed, 23 skipped, 0 failed**. The 23 remote integration tests remain skipped because they require a configured isolated `COMEIN_TEST_BASE_URL` deployment; some also require test-only admin credentials or service dependencies. |
| Frontend typecheck | **Blocked** | `cd frontend && npm run typecheck` — exit 2. `node_modules` and `expo/tsconfig.base` are missing; unresolved Expo/React Native modules mean the run cannot establish whether the source typechecks. |
| Frontend lint | **Blocked** | `cd frontend && npm run lint` — exit 127, `expo: not found`. |
| Web production build | **Blocked** | `cd frontend && npm run build:web` — exit 127, `expo: not found`. |
| Manual browser/device runtime review | **Not run by request** | App was not launched and Replit was not opened. |
| Live API, MongoDB, payment-provider checks | **Not run** | No external services or live/test payment credentials used. |

The backend suite uses local/source-level tests and does not prove browser rendering or live API integration. Skipped tests are not counted as passes.

## Package hygiene and archive verification

- Archive root: `COME-IN/`.
- Included the existing README files, project docs, backend requirements, frontend package manifest, source, assets, and safe `.env.example` templates.
- No real `.env` file is intended to be included. `.env.example` templates are retained.
- `node_modules`, `.expo`, `.git`, Python caches/bytecode, TypeScript build caches, temporary logs, and generated build output are excluded from the archive.
- The project has no `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` in the source snapshot; none was fabricated. `frontend/package.json` declares Yarn 1.22.22.
- The original source ZIP is kept as a separate backup; this package uses a separate filename.

The final archive byte size, SHA-256, entry count, required-file checks, forbidden-artifact scan, and `unzip -t` result are supplied in the accompanying external report after archive creation.

## Remaining blockers / limitations

1. Frontend typecheck, lint, and production build need the declared dependencies installed. This environment has no `node_modules`, and dependency installation was not attempted because previous registry access failed and no network-dependent result should be invented.
2. The 23 remote integration tests need a disposable configured test deployment and any required test-only credentials/services.
3. iOS 26+ native tab colors are managed by Expo NativeTabs/system styling; only the classic JavaScript tab bar was themed in code.
4. The available attached reference image shows Restaurant Mode's pink screens, not the requested yellow/mint Shopping Mode home. The explicit written theme requirements were implemented, and Restaurant Mode's separate theme was preserved; pixel-perfect comparison to a matching Shopping Mode screenshot remains unavailable.
5. No runtime/browser visual check was performed, as explicitly requested.
