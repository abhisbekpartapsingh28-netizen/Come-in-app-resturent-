# COME-IN Replit Preview Readiness — Follow-up

## Changes in this follow-up

- `scripts/replit-run.sh`: does not make missing MongoDB/JWT configuration prevent the Expo frontend from starting. It logs the exact backend blocker and starts FastAPI only when `MONGO_URL`, `DB_NAME`, and a non-placeholder `JWT_SECRET` exist. When configured, it still starts both processes and monitors their exit status.
- `README.md`: clarifies frontend-only preview behavior, backend secrets, and why `localhost` is not a valid hosted browser API URL.

No application business logic, screens, APIs, Restaurant Mode, Shopping Mode, database data, or payment logic was changed. No real secrets were added.

## Checks actually run

- `bash -n scripts/replit-run.sh scripts/replit-install.sh` — PASSED.
- `PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests tests` — PASSED: 25 passed, 23 skipped, 0 failed. Skipped tests require remote integration prerequisites and are not counted as passed.
- `python -m py_compile backend/server.py backend/restaurant_pricing.py` — PASSED (syntax only).
- `node --version` — v22.16.0; `npm --version` — 10.9.2; Python — 3.13.5.
- `npm install --ignore-scripts --no-audit --no-fund --prefer-offline` in `frontend/` — BLOCKED/TIMED OUT after 120 seconds. No install/build success is claimed. No lockfile was fabricated.
- Frontend typecheck, lint, web build, live backend startup, MongoDB connectivity, browser screenshot, and Replit Preview — NOT RUN / NOT VERIFIED.

## Important remaining blockers

1. Dependency installation is blocked in this environment by the package-registry/network timeout.
2. No real `MONGO_URL`, `DB_NAME`, or `JWT_SECRET` is available in this environment. Without these, FastAPI is intentionally not started; the Expo frontend can still start for visual preview, but API-backed features will not work until backend configuration is supplied.
3. `EXPO_PUBLIC_BACKEND_URL` must be set to the externally reachable backend origin for the actual Replit workspace before restarting Expo. Do not use browser-side `localhost` for a hosted preview. Whether port 8000 is publicly exposed depends on Replit workspace routing; if not, a same-origin proxy is required.
4. No Replit workspace connector/authorization is available here, so Replit was not opened and no Preview URL can be claimed.

## Run configuration

- `.replit` Run command: `bash ./scripts/replit-run.sh`
- Expo web: port 3000, bound via Expo LAN host mode.
- FastAPI (when configured): `0.0.0.0:8000`.
- Install helper: `bash ./scripts/replit-install.sh`.

Required backend Secrets: `MONGO_URL`, `DB_NAME`, `JWT_SECRET`. For frontend API access: `EXPO_PUBLIC_BACKEND_URL` must be an externally reachable backend URL, with compatible `CORS_ORIGINS` configured on the backend.
