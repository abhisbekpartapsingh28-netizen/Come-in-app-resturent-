# COME-IN — Existing App (Portable Preview Package)

This ZIP contains the existing COME-IN Expo Router frontend and FastAPI backend. It is a source package, not a compiled app or a promise that all external integrations are configured. The original logo, screens, routing, theme, and application modules are preserved; this preparation focuses on import/run instructions and dependency-startup clarity.

## Project structure

- `frontend/` — Expo SDK / Expo Router / React Native Web application.
- `backend/` — FastAPI APIs, MongoDB Motor integration, authentication, and backend tests.
- `scripts/replit-install.sh` — installs using the frontend's declared Yarn package manager and `backend/requirements.txt`.
- `scripts/replit-run.sh` — starts Expo Web on port 3000; starts the API on port 8000 only when required backend Secrets are present.
- `.replit` — existing Replit Run workflow and port mappings.
- `.env.example` — safe placeholders only; do not use the sample secret in a real environment.
- `IMPLEMENTATION_STATUS.md` and test reports — documented scope and limitations.

## Prerequisites

- Node.js compatible with the Expo SDK in `frontend/package.json`; Corepack or Yarn 1.22.22.
- Python compatible with `backend/requirements.txt`.
- Network access to the configured npm/Yarn and Python package registries for a first install.
- MongoDB and backend secrets only for API-backed features; the frontend can start without backend configuration.

## Replit: import and Preview

1. Import/upload this ZIP so that `.replit`, `frontend/`, `backend/`, and `scripts/` are at the project root (the ZIP has one `COME-IN/` top-level folder; if the importer opens that folder as the project root, use it directly).
2. In the Replit Shell, run once:

   ```bash
   bash ./scripts/replit-install.sh
   ```

3. Press **Run**. The configured command is `bash ./scripts/replit-run.sh`.
4. Open the workspace's **Preview** for the frontend port 3000 (configured external port 80). Do not use a public Deployment URL as a substitute for the development Preview.
5. Backend/API features need `MONGO_URL`, `DB_NAME`, and a unique `JWT_SECRET` in Replit Secrets. Set `EXPO_PUBLIC_BACKEND_URL` to the externally reachable backend origin before starting Expo if browser API requests are required. `localhost:8000` is generally not reachable from a browser on a separate device/workspace origin.

## Emergent: import and Preview

1. Import the ZIP/source into an existing supported development workspace. Ensure the workspace opens the extracted `COME-IN/` directory as its project root; commands below assume that root.
2. In its terminal, install dependencies:

   ```bash
   bash ./scripts/replit-install.sh
   ```

3. Start the frontend for Preview:

   ```bash
   cd frontend && yarn start --host lan
   ```

   If the platform requires an explicit host/port field, configure the frontend service to listen on port `3000` and bind to all interfaces as supported by that platform. Expo CLI host options vary by version, so follow the platform's supported Preview configuration rather than assuming Replit port mapping transfers to Emergent.
4. Start backend separately only when configured:

   ```bash
   cd backend && python -m uvicorn server:app --host 0.0.0.0 --port 8000
   ```

   Set `MONGO_URL`, `DB_NAME`, and a unique `JWT_SECRET` in the workspace's environment/Secrets before starting the backend. Set `EXPO_PUBLIC_BACKEND_URL` to a URL the browser can reach and restart Expo after changing it.

## Local development commands

Install both sides:

```bash
bash ./scripts/replit-install.sh
```

Frontend only:

```bash
cd frontend && yarn start --web --port 3000
```

Backend (requires environment variables and MongoDB):

```bash
cd backend && python -m uvicorn server:app --host 0.0.0.0 --port 8000
```

Backend tests (from project root):

```bash
cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests
```

## Environment variables and service requirements

- Required to start the backend: `MONGO_URL`, `DB_NAME`, and a unique `JWT_SECRET`. The backend does not use a fake database when these are absent.
- Required for browser-to-backend calls: `EXPO_PUBLIC_BACKEND_URL` must point to a reachable backend origin and be set before Expo builds the client bundle.
- Optional integrations: SMTP settings for password reset email; Razorpay keys and webhook configuration for payment integration; `EMERGENT_LLM_KEY` for the existing object-storage integration described by the source. Each external service must be configured and tested separately.
- Do not put real credentials in `.env.example`, commit a real `.env`, or include private database contents in a backup.

## Troubleshooting

- **Registry/DNS failure:** if install reports `Could not resolve host`, `EAI_AGAIN`, or a package index connection error, stop retrying. Verify registry access from the target workspace; a DNS error in a different environment does not prove the target platform has the same problem.
- **Yarn/Corepack missing:** use a workspace image that includes Node.js/Corepack or install the declared Yarn version through the platform's supported package-manager mechanism.
- **Preview 404 / no previewable artifacts:** open the active development workspace's Preview, not a deployment URL. Confirm the Expo process is running and the workspace Preview is targeting frontend port 3000.
- **Port not reachable:** confirm the frontend logs show Expo started on port 3000 and configure the platform Preview port to that port. Do not point frontend Preview to backend port 8000.
- **Backend does not start:** configure MongoDB connectivity and the required Secrets. This should not by itself prevent the frontend UI process from starting.
- **UI opens but API requests fail:** set `EXPO_PUBLIC_BACKEND_URL` to a browser-reachable backend URL, configure exact `CORS_ORIGINS`, then restart Expo and the backend.
- **Blank screen or route error:** inspect Expo/Metro logs first. Root `frontend/app/index.tsx` redirects to the existing `/(tabs)` route; verify the route group files remain present.

## Verification status (2026-10-17)

- ZIP source integrity was checked before preparation; this package is created from that existing source.
- Backend tests in the available local environment: **25 passed, 23 skipped, 0 failed**.
- Frontend dependency installation, typecheck, web export, HTTP root route, and actual Replit/Emergent Preview were **not verified** in this environment because `registry.npmjs.org` DNS did not resolve. This is a local environment observation, not proof that Replit or Emergent has the same network issue.
- No production deployment or database migration was performed.
