# COME-IN — Current Work Backup

This archive combines the original full project (including its existing backend and tests) with the latest available frontend implementation copy for Shopping Mode and Restaurant Mode. The original source ZIP in the workspace was not modified.

## Project layout
- `frontend/` — Expo + React Native + TypeScript + Expo Router + React Native Web app, including Restaurant Mode screens/components.
- `backend/` — existing backend files from the original project archive.
- `tests/`, `test_reports/` and project docs — retained from the original project where present, plus implementation notes.
- `previews/` — two design-preview PNGs. They are mockups, not screenshots captured from a running app.

## Start the web app
1. Install a compatible Node.js version and Yarn (the frontend package manifest specifies Yarn 1.22.x).
2. Open a terminal in `frontend/`.
3. Install dependencies using the project's package manager. No lockfile was present in the supplied project ZIP, so exact dependency resolution is not guaranteed.
4. Run `yarn start` to invoke the configured Expo web command (`expo start --web --port 3000`).
5. If Expo reports missing dependencies, network errors, or configuration issues, resolve those before considering the app runnable. Do not run the destructive `reset-project` script for preview.

## Backend setup
- Backend is FastAPI + MongoDB/Motor. Copy `backend/.env.example` to `backend/.env` and set real values locally. Never commit `backend/.env`.
- Install `backend/requirements.txt`, then run `uvicorn server:app --reload --app-dir backend` from the project root after MongoDB is reachable.
- MongoDB collections are schemaless; startup creates indexes. Restaurant records remain pending until an admin approves them.
- Configure SMTP settings to enable password reset email. Configure Razorpay server keys and webhook secret, the provider dashboard webhook, and a checkout UI adapter before enabling online payments.

## Current limitations
- The prior attempt to start the app reported `expo: not found`; the live preview has not been verified.
- Restaurant sample data/cart/order flows are development/demo functionality, not a connected live restaurant, payment, or fulfilment service.
- Backend/database/API integration and end-to-end runtime tests remain to be verified.
- The provided preview PNGs are design previews, not runtime screenshots.
- No `node_modules`, build cache, or `.env` credentials are included intentionally.

## Security and integrity
- This package does not intentionally include `.env` files or `node_modules`. Review configuration locally before publishing.
- Original project source archive was preserved; this is a separate bundle.
